import pandas as pd
from data.frameworks_data import get_industry_framework_mapping, get_all_frameworks
from utils.analysis import calculate_framework_score, get_user_specific_weights

def get_industry_recommendations(industry, top_n=8):
    """Get framework recommendations for a specific industry"""
    
    industry_mapping = get_industry_framework_mapping()
    frameworks_df = get_all_frameworks()
    
    if industry not in industry_mapping:
        return pd.DataFrame(), f"No specific recommendations available for {industry}"
    
    recommended_names = industry_mapping[industry]
    recommended_frameworks = frameworks_df[frameworks_df['name'].isin(recommended_names)]
    
    # Calculate scores for recommended frameworks
    recommended_frameworks = recommended_frameworks.copy()
    recommended_frameworks['score'] = recommended_frameworks.apply(
        lambda row: calculate_framework_score(row), axis=1
    )
    
    # Sort by score and return top N
    top_recommendations = recommended_frameworks.sort_values('score', ascending=False).head(top_n)
    
    return top_recommendations, None

def get_smart_recommendations(user_inputs):
    """Generate smart recommendations based on multiple user inputs"""
    
    frameworks_df = get_all_frameworks()
    
    # Extract user inputs
    industry = user_inputs.get('industry')
    company_size = user_inputs.get('company_size', 'Medium')
    budget = user_inputs.get('budget', 'Medium')
    timeline = user_inputs.get('timeline', 'Medium')
    experience_level = user_inputs.get('experience_level', 'Intermediate')
    primary_goal = user_inputs.get('primary_goal', 'General Improvement')
    
    # Get user-specific weights
    weights = get_user_specific_weights(company_size, budget, timeline, experience_level)
    
    # Calculate base scores
    scored_frameworks = frameworks_df.copy()
    scored_frameworks['base_score'] = scored_frameworks.apply(
        lambda row: calculate_framework_score(row, weights), axis=1
    )
    
    # Apply industry bonus
    industry_bonus = 0
    if industry:
        industry_mapping = get_industry_framework_mapping()
        if industry in industry_mapping:
            recommended_names = industry_mapping[industry]
            scored_frameworks['industry_match'] = scored_frameworks['name'].isin(recommended_names)
            industry_bonus = 15
            scored_frameworks.loc[scored_frameworks['industry_match'], 'base_score'] += industry_bonus
    
    # Apply goal-specific bonuses
    goal_bonus = apply_goal_specific_bonus(scored_frameworks, primary_goal)
    scored_frameworks['final_score'] = scored_frameworks['base_score'] + goal_bonus
    
    # Apply constraint filters
    filtered_frameworks = apply_constraint_filters(scored_frameworks, user_inputs)
    
    # Sort by final score
    recommendations = filtered_frameworks.sort_values('final_score', ascending=False).head(10)
    
    # Generate explanation
    explanation = generate_recommendation_explanation(user_inputs, industry_bonus > 0)
    
    return recommendations, explanation

def apply_goal_specific_bonus(frameworks_df, primary_goal):
    """Apply bonuses based on user's primary goal"""
    
    goal_framework_mapping = {
        'Strategic Planning': [
            'SWOT Analysis', 'Porter\'s Five Forces', 'PESTEL Analysis', 'Balanced Scorecard',
            'Scenario Planning', 'McKinsey 7S Framework'
        ],
        'Process Improvement': [
            'Lean Management', 'Six Sigma', 'PDCA Cycle', 'Kaizen', '5S Methodology',
            'Total Quality Management (TQM)', 'DMAIC'
        ],
        'Innovation': [
            'Design Thinking', 'Business Model Canvas', 'Blue Ocean Strategy', 'TRIZ',
            'Innovation Funnel', 'Open Innovation Model'
        ],
        'Marketing': [
            'Marketing Mix (4Ps)', 'Customer Journey Mapping', 'RACE Framework', 
            'RFM Analysis', 'CLV Calculation', 'Omnichannel Marketing'
        ],
        'Project Management': [
            'Scrum', 'Kanban', 'Critical Path Method (CPM)', 'PERT', 
            'Earned Value Management (EVM)', 'PRINCE2'
        ],
        'Change Management': [
            'Kotter\'s 8-Step Model', 'ADKAR Model', 'Lewin\'s Change Model',
            'Force Field Analysis', 'Appreciative Inquiry'
        ],
        'Risk Management': [
            'COSO ERM Framework', 'ISO 31000', 'Risk Heat Map', 'Bow-Tie Analysis', 'FMEA'
        ],
        'Financial Analysis': [
            'DuPont Analysis', 'Net Present Value (NPV)', 'Internal Rate of Return (IRR)',
            'Cost-Benefit Analysis (CBA)', 'Break-Even Analysis'
        ]
    }
    
    bonus_series = pd.Series(0, index=frameworks_df.index)
    
    if primary_goal in goal_framework_mapping:
        relevant_frameworks = goal_framework_mapping[primary_goal]
        mask = frameworks_df['name'].isin(relevant_frameworks)
        bonus_series[mask] = 20
    
    return bonus_series

def apply_constraint_filters(frameworks_df, user_inputs):
    """Apply user constraint filters to framework selection"""
    
    # Define constraint mappings
    budget_constraints = {
        'Low': 2,
        'Medium': 3,
        'High': 5
    }
    
    timeline_constraints = {
        'Urgent': 2,
        'Medium': 3,
        'Flexible': 5
    }
    
    experience_constraints = {
        'Beginner': 3,
        'Intermediate': 4,
        'Expert': 5
    }
    
    # Apply filters
    filtered_df = frameworks_df.copy()
    
    # Budget filter
    budget = user_inputs.get('budget', 'Medium')
    max_cost = budget_constraints.get(budget, 5)
    filtered_df = filtered_df[filtered_df['cost'] <= max_cost]
    
    # Timeline filter
    timeline = user_inputs.get('timeline', 'Medium')
    max_time = timeline_constraints.get(timeline, 5)
    filtered_df = filtered_df[filtered_df['time_to_implement'] <= max_time]
    
    # Experience filter
    experience = user_inputs.get('experience_level', 'Intermediate')
    max_complexity = experience_constraints.get(experience, 5)
    filtered_df = filtered_df[filtered_df['complexity'] <= max_complexity]
    
    return filtered_df

def generate_recommendation_explanation(user_inputs, has_industry_match):
    """Generate explanation for the recommendations"""
    
    explanations = []
    
    # Industry explanation
    if has_industry_match:
        industry = user_inputs.get('industry')
        explanations.append(f"✅ Prioritized frameworks commonly used in {industry}")
    
    # Company size explanation
    company_size = user_inputs.get('company_size', 'Medium')
    if company_size == 'Small':
        explanations.append("💰 Emphasized cost-effective and simple-to-implement frameworks")
    elif company_size == 'Large':
        explanations.append("🎯 Focused on high-impact frameworks suitable for large organizations")
    
    # Budget explanation
    budget = user_inputs.get('budget', 'Medium')
    if budget == 'Low':
        explanations.append("💸 Filtered out high-cost implementation frameworks")
    elif budget == 'High':
        explanations.append("💎 Included premium frameworks with higher implementation costs")
    
    # Timeline explanation
    timeline = user_inputs.get('timeline', 'Medium')
    if timeline == 'Urgent':
        explanations.append("⚡ Prioritized quick-to-implement frameworks")
    elif timeline == 'Flexible':
        explanations.append("📅 Included frameworks with longer implementation timelines")
    
    # Experience explanation
    experience = user_inputs.get('experience_level', 'Intermediate')
    if experience == 'Beginner':
        explanations.append("🎓 Focused on beginner-friendly frameworks with lower complexity")
    elif experience == 'Expert':
        explanations.append("🚀 Included advanced frameworks suitable for expert practitioners")
    
    # Goal explanation
    primary_goal = user_inputs.get('primary_goal')
    if primary_goal and primary_goal != 'General Improvement':
        explanations.append(f"🎯 Boosted frameworks specifically designed for {primary_goal}")
    
    return explanations

def get_framework_alternatives(framework_name, n_alternatives=5):
    """Get alternative frameworks for a given framework"""
    
    frameworks_df = get_all_frameworks()
    target_framework = frameworks_df[frameworks_df['name'] == framework_name]
    
    if target_framework.empty:
        return pd.DataFrame(), "Framework not found"
    
    target = target_framework.iloc[0]
    
    # Find frameworks in the same category first
    same_category = frameworks_df[
        (frameworks_df['category'] == target['category']) & 
        (frameworks_df['name'] != framework_name)
    ]
    
    # Calculate similarity scores
    alternatives = []
    
    for _, framework in frameworks_df.iterrows():
        if framework['name'] == framework_name:
            continue
        
        # Calculate similarity
        complexity_sim = 1 - abs(framework['complexity'] - target['complexity']) / 4
        time_sim = 1 - abs(framework['time_to_implement'] - target['time_to_implement']) / 4
        cost_sim = 1 - abs(framework['cost'] - target['cost']) / 4
        effectiveness_sim = 1 - abs(framework['effectiveness'] - target['effectiveness']) / 4
        
        # Category bonus
        category_bonus = 0.3 if framework['category'] == target['category'] else 0
        
        similarity = (complexity_sim + time_sim + cost_sim + effectiveness_sim) / 4 + category_bonus
        
        alternatives.append({
            'name': framework['name'],
            'category': framework['category'],
            'similarity_score': round(similarity, 3),
            'complexity': framework['complexity'],
            'time_to_implement': framework['time_to_implement'],
            'cost': framework['cost'],
            'effectiveness': framework['effectiveness'],
            'core_function': framework['core_function']
        })
    
    # Sort by similarity and return top N
    alternatives_df = pd.DataFrame(alternatives).sort_values('similarity_score', ascending=False)
    
    return alternatives_df.head(n_alternatives), None

def get_complementary_frameworks(selected_frameworks, n_recommendations=5):
    """Get frameworks that complement the selected ones"""
    
    frameworks_df = get_all_frameworks()
    
    if not selected_frameworks:
        return pd.DataFrame(), "Please select at least one framework"
    
    # Get selected framework data
    selected_df = frameworks_df[frameworks_df['name'].isin(selected_frameworks)]
    
    # Calculate average characteristics of selected frameworks
    avg_complexity = selected_df['complexity'].mean()
    avg_time = selected_df['time_to_implement'].mean()
    avg_cost = selected_df['cost'].mean()
    avg_effectiveness = selected_df['effectiveness'].mean()
    
    # Get categories of selected frameworks
    selected_categories = set(selected_df['category'].unique())
    
    # Find complementary frameworks
    remaining_frameworks = frameworks_df[~frameworks_df['name'].isin(selected_frameworks)]
    
    complementary_scores = []
    
    for _, framework in remaining_frameworks.iterrows():
        # Category diversity bonus
        category_bonus = 0.3 if framework['category'] not in selected_categories else 0
        
        # Characteristic balance score (prefer frameworks that balance the selection)
        balance_score = 0
        
        # If selected frameworks are complex, prefer simpler ones
        if avg_complexity > 3:
            balance_score += (5 - framework['complexity']) / 4 * 0.25
        else:
            balance_score += framework['complexity'] / 5 * 0.25
        
        # If selected frameworks take long to implement, prefer quicker ones
        if avg_time > 3:
            balance_score += (5 - framework['time_to_implement']) / 4 * 0.25
        else:
            balance_score += framework['time_to_implement'] / 5 * 0.25
        
        # Always prefer high effectiveness
        balance_score += framework['effectiveness'] / 5 * 0.3
        
        # Cost consideration (prefer lower cost)
        balance_score += (5 - framework['cost']) / 4 * 0.2
        
        total_score = balance_score + category_bonus
        
        complementary_scores.append({
            'name': framework['name'],
            'category': framework['category'],
            'complementary_score': round(total_score, 3),
            'complexity': framework['complexity'],
            'time_to_implement': framework['time_to_implement'],
            'cost': framework['cost'],
            'effectiveness': framework['effectiveness'],
            'core_function': framework['core_function'],
            'category_diversity': framework['category'] not in selected_categories
        })
    
    # Sort by complementary score
    complementary_df = pd.DataFrame(complementary_scores).sort_values('complementary_score', ascending=False)
    
    return complementary_df.head(n_recommendations), None

def get_implementation_roadmap(selected_frameworks):
    """Generate an implementation roadmap for selected frameworks"""
    
    frameworks_df = get_all_frameworks()
    
    if not selected_frameworks:
        return [], "Please select frameworks to create a roadmap"
    
    # Get selected framework data
    selected_df = frameworks_df[frameworks_df['name'].isin(selected_frameworks)].copy()
    
    # Create implementation phases based on dependencies and characteristics
    roadmap = []
    
    # Sort frameworks by implementation strategy
    # Phase 1: Quick wins (low complexity, low time, high effectiveness)
    phase1 = selected_df[
        (selected_df['complexity'] <= 2) & 
        (selected_df['time_to_implement'] <= 2)
    ].sort_values('effectiveness', ascending=False)
    
    # Phase 2: Foundation frameworks (medium complexity/time)
    phase2 = selected_df[
        (selected_df['complexity'] == 3) | 
        (selected_df['time_to_implement'] == 3)
    ].sort_values('effectiveness', ascending=False)
    
    # Phase 3: Advanced frameworks (high complexity/time)
    phase3 = selected_df[
        (selected_df['complexity'] >= 4) | 
        (selected_df['time_to_implement'] >= 4)
    ].sort_values('effectiveness', ascending=False)
    
    # Build roadmap
    current_month = 0
    
    if not phase1.empty:
        roadmap.append({
            'phase': 'Phase 1: Quick Wins',
            'start_month': current_month,
            'duration': int(phase1['time_to_implement'].max()),
            'frameworks': phase1['name'].tolist(),
            'description': 'Low complexity, high-impact frameworks to build momentum',
            'total_cost': int(phase1['cost'].sum()),
            'expected_effectiveness': round(phase1['effectiveness'].mean(), 1)
        })
        current_month += int(phase1['time_to_implement'].max())
    
    if not phase2.empty:
        roadmap.append({
            'phase': 'Phase 2: Foundation',
            'start_month': current_month,
            'duration': int(phase2['time_to_implement'].max()),
            'frameworks': phase2['name'].tolist(),
            'description': 'Medium complexity frameworks to build organizational capability',
            'total_cost': int(phase2['cost'].sum()),
            'expected_effectiveness': round(phase2['effectiveness'].mean(), 1)
        })
        current_month += int(phase2['time_to_implement'].max())
    
    if not phase3.empty:
        roadmap.append({
            'phase': 'Phase 3: Advanced',
            'start_month': current_month,
            'duration': int(phase3['time_to_implement'].max()),
            'frameworks': phase3['name'].tolist(),
            'description': 'High complexity, strategic frameworks for competitive advantage',
            'total_cost': int(phase3['cost'].sum()),
            'expected_effectiveness': round(phase3['effectiveness'].mean(), 1)
        })
    
    return roadmap, None

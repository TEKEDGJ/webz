import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import plotly.express as px
import plotly.graph_objects as go

def perform_framework_clustering(frameworks_df, n_clusters=5):
    """Perform clustering analysis on frameworks based on their characteristics"""
    
    # Select numerical features for clustering
    features = ['complexity', 'time_to_implement', 'cost', 'effectiveness']
    X = frameworks_df[features].copy()
    
    # Standardize the features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Perform K-means clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    clusters = kmeans.fit_predict(X_scaled)
    
    # Add cluster labels to dataframe
    frameworks_df_clustered = frameworks_df.copy()
    frameworks_df_clustered['cluster'] = clusters
    
    # Calculate cluster characteristics
    cluster_summary = frameworks_df_clustered.groupby('cluster')[features].mean().round(2)
    
    return frameworks_df_clustered, cluster_summary

def calculate_framework_score(framework_data, weights=None):
    """Calculate a composite score for a framework based on weighted characteristics"""
    
    if weights is None:
        weights = {
            'complexity': -0.2,  # Lower complexity is better
            'time_to_implement': -0.2,  # Faster implementation is better
            'cost': -0.3,  # Lower cost is better
            'effectiveness': 0.5  # Higher effectiveness is better
        }
    
    # Normalize values to 0-1 scale
    normalized_complexity = 1 - (framework_data['complexity'] - 1) / 4
    normalized_time = 1 - (framework_data['time_to_implement'] - 1) / 4
    normalized_cost = 1 - (framework_data['cost'] - 1) / 4
    normalized_effectiveness = (framework_data['effectiveness'] - 1) / 4
    
    # Calculate weighted score
    score = (
        weights['complexity'] * normalized_complexity +
        weights['time_to_implement'] * normalized_time +
        weights['cost'] * normalized_cost +
        weights['effectiveness'] * normalized_effectiveness
    )
    
    # Scale to 0-100
    return max(0, min(100, (score + 1) * 50))

def analyze_category_performance(frameworks_df):
    """Analyze performance metrics by category"""
    
    category_stats = frameworks_df.groupby('category').agg({
        'complexity': ['mean', 'std'],
        'time_to_implement': ['mean', 'std'],
        'cost': ['mean', 'std'],
        'effectiveness': ['mean', 'std']
    }).round(2)
    
    # Flatten column names
    category_stats.columns = ['_'.join(col).strip() for col in category_stats.columns]
    
    # Calculate category scores
    category_scores = {}
    for category in frameworks_df['category'].unique():
        category_frameworks = frameworks_df[frameworks_df['category'] == category]
        avg_score = np.mean([
            calculate_framework_score(row) 
            for _, row in category_frameworks.iterrows()
        ])
        category_scores[category] = round(avg_score, 2)
    
    return category_stats, category_scores

def find_similar_frameworks(target_framework, frameworks_df, n_similar=5):
    """Find frameworks similar to a target framework"""
    
    if isinstance(target_framework, str):
        target_data = frameworks_df[frameworks_df['name'] == target_framework].iloc[0]
    else:
        target_data = target_framework
    
    # Calculate similarity scores
    similarity_scores = []
    
    for _, framework in frameworks_df.iterrows():
        if framework['name'] == target_data['name']:
            continue
            
        # Calculate similarity based on characteristics
        complexity_sim = 1 - abs(framework['complexity'] - target_data['complexity']) / 4
        time_sim = 1 - abs(framework['time_to_implement'] - target_data['time_to_implement']) / 4
        cost_sim = 1 - abs(framework['cost'] - target_data['cost']) / 4
        effectiveness_sim = 1 - abs(framework['effectiveness'] - target_data['effectiveness']) / 4
        
        # Bonus for same category
        category_bonus = 0.2 if framework['category'] == target_data['category'] else 0
        
        # Overall similarity
        similarity = (complexity_sim + time_sim + cost_sim + effectiveness_sim) / 4 + category_bonus
        
        similarity_scores.append({
            'name': framework['name'],
            'category': framework['category'],
            'similarity': similarity,
            'complexity': framework['complexity'],
            'time_to_implement': framework['time_to_implement'],
            'cost': framework['cost'],
            'effectiveness': framework['effectiveness']
        })
    
    # Sort by similarity and return top N
    similarity_scores.sort(key=lambda x: x['similarity'], reverse=True)
    
    return similarity_scores[:n_similar]

def perform_pca_analysis(frameworks_df):
    """Perform Principal Component Analysis on framework characteristics"""
    
    # Select numerical features
    features = ['complexity', 'time_to_implement', 'cost', 'effectiveness']
    X = frameworks_df[features]
    
    # Standardize the features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Perform PCA
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    
    # Create PCA dataframe
    pca_df = pd.DataFrame({
        'PC1': X_pca[:, 0],
        'PC2': X_pca[:, 1],
        'name': frameworks_df['name'],
        'category': frameworks_df['category']
    })
    
    # Calculate explained variance
    explained_variance = pca.explained_variance_ratio_
    
    # Get feature contributions
    components = pd.DataFrame(
        pca.components_.T,
        columns=['PC1', 'PC2'],
        index=features
    )
    
    return pca_df, explained_variance, components

def create_pca_visualization(pca_df, explained_variance):
    """Create PCA visualization plot"""
    
    fig = px.scatter(
        pca_df,
        x='PC1',
        y='PC2',
        color='category',
        hover_name='name',
        title=f"PCA Analysis of Business Frameworks<br>PC1: {explained_variance[0]:.1%} variance, PC2: {explained_variance[1]:.1%} variance"
    )
    
    fig.update_layout(
        xaxis_title=f"First Principal Component ({explained_variance[0]:.1%} variance)",
        yaxis_title=f"Second Principal Component ({explained_variance[1]:.1%} variance)"
    )
    
    return fig

def analyze_implementation_feasibility(frameworks_df, user_constraints):
    """Analyze framework feasibility based on user constraints"""
    
    # Default constraints if not provided
    default_constraints = {
        'max_complexity': 5,
        'max_time': 5,
        'max_cost': 5,
        'min_effectiveness': 1
    }
    
    constraints = {**default_constraints, **user_constraints}
    
    # Filter frameworks based on constraints
    feasible_frameworks = frameworks_df[
        (frameworks_df['complexity'] <= constraints['max_complexity']) &
        (frameworks_df['time_to_implement'] <= constraints['max_time']) &
        (frameworks_df['cost'] <= constraints['max_cost']) &
        (frameworks_df['effectiveness'] >= constraints['min_effectiveness'])
    ].copy()
    
    # Calculate feasibility scores
    feasible_frameworks['feasibility_score'] = feasible_frameworks.apply(
        lambda row: calculate_framework_score(row), axis=1
    )
    
    # Sort by feasibility score
    feasible_frameworks = feasible_frameworks.sort_values('feasibility_score', ascending=False)
    
    return feasible_frameworks

def generate_framework_recommendations(frameworks_df, user_profile):
    """Generate personalized framework recommendations based on user profile"""
    
    # Extract user preferences
    industry = user_profile.get('industry', '')
    company_size = user_profile.get('company_size', 'Medium')
    budget = user_profile.get('budget', 'Medium')
    timeline = user_profile.get('timeline', 'Medium')
    experience_level = user_profile.get('experience_level', 'Intermediate')
    
    # Define scoring weights based on user profile
    weights = get_user_specific_weights(company_size, budget, timeline, experience_level)
    
    # Calculate scores for all frameworks
    scored_frameworks = frameworks_df.copy()
    scored_frameworks['recommendation_score'] = scored_frameworks.apply(
        lambda row: calculate_framework_score(row, weights), axis=1
    )
    
    # Industry-specific filtering if available
    if industry:
        from data.frameworks_data import get_industry_framework_mapping
        industry_mapping = get_industry_framework_mapping()
        
        if industry in industry_mapping:
            recommended_names = industry_mapping[industry]
            scored_frameworks['industry_match'] = scored_frameworks['name'].isin(recommended_names)
            # Boost scores for industry-specific frameworks
            scored_frameworks.loc[scored_frameworks['industry_match'], 'recommendation_score'] += 20
    
    # Sort by recommendation score
    recommendations = scored_frameworks.sort_values('recommendation_score', ascending=False)
    
    return recommendations.head(10)

def get_user_specific_weights(company_size, budget, timeline, experience_level):
    """Get framework scoring weights based on user characteristics"""
    
    weights = {
        'complexity': -0.2,
        'time_to_implement': -0.2,
        'cost': -0.3,
        'effectiveness': 0.5
    }
    
    # Adjust weights based on company size
    if company_size == 'Small':
        weights['cost'] = -0.4  # Cost is more important for small companies
        weights['complexity'] = -0.3  # Prefer simpler frameworks
    elif company_size == 'Large':
        weights['effectiveness'] = 0.6  # Focus more on effectiveness
        weights['complexity'] = -0.1  # Can handle more complexity
    
    # Adjust weights based on budget
    if budget == 'Low':
        weights['cost'] = -0.5
    elif budget == 'High':
        weights['cost'] = -0.1
    
    # Adjust weights based on timeline
    if timeline == 'Urgent':
        weights['time_to_implement'] = -0.4
    elif timeline == 'Flexible':
        weights['time_to_implement'] = -0.1
    
    # Adjust weights based on experience level
    if experience_level == 'Beginner':
        weights['complexity'] = -0.4
    elif experience_level == 'Expert':
        weights['complexity'] = 0.1  # Complex frameworks might be preferred
    
    return weights

def calculate_roi_estimation(framework_data, implementation_params):
    """Calculate estimated ROI for implementing a framework"""
    
    # Base parameters
    base_benefit = implementation_params.get('expected_benefit', 100000)  # $
    implementation_cost = framework_data['cost'] * implementation_params.get('cost_multiplier', 10000)  # $
    implementation_time = framework_data['time_to_implement']  # months
    effectiveness_multiplier = framework_data['effectiveness'] / 5  # 0-1 scale
    
    # Calculate benefits
    annual_benefit = base_benefit * effectiveness_multiplier
    implementation_benefit = annual_benefit * (implementation_time / 12)
    
    # Calculate ROI
    roi = ((annual_benefit - implementation_cost) / implementation_cost) * 100
    
    # Calculate payback period
    payback_months = implementation_cost / (annual_benefit / 12) if annual_benefit > 0 else float('inf')
    
    return {
        'roi_percentage': round(roi, 2),
        'payback_months': round(payback_months, 1),
        'annual_benefit': round(annual_benefit, 0),
        'implementation_cost': round(implementation_cost, 0),
        'net_annual_value': round(annual_benefit - implementation_cost, 0)
    }

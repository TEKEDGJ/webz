import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import networkx as nx

def create_framework_radar_chart(framework_data, parameters):
    """Create a radar chart for framework characteristics"""
    
    # Define the categories and their values
    categories = ['Complexity', 'Time to Implement', 'Cost', 'Effectiveness']
    
    # Get values from framework data or use parameters
    values = [
        parameters.get('complexity', framework_data.get('complexity', 3)),
        parameters.get('time_to_implement', framework_data.get('time_to_implement', 3)),
        parameters.get('cost', framework_data.get('cost', 3)),
        parameters.get('effectiveness', framework_data.get('effectiveness', 3))
    ]
    
    # Create radar chart
    fig = go.Figure()
    
    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        name=framework_data.get('name', 'Framework'),
        line_color='#FF6B6B'
    ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 5]
            )),
        showlegend=True,
        title=f"Framework Characteristics: {framework_data.get('name', 'Unknown')}"
    )
    
    return fig

def create_category_distribution_chart(frameworks_df):
    """Create a pie chart showing distribution of frameworks by category"""
    
    category_counts = frameworks_df['category'].value_counts()
    
    fig = px.pie(
        values=category_counts.values,
        names=category_counts.index,
        title="Distribution of Frameworks by Category"
    )
    
    fig.update_traces(textposition='inside', textinfo='percent+label')
    
    return fig

def create_complexity_scatter(frameworks_df):
    """Create scatter plot of complexity vs effectiveness"""
    
    fig = px.scatter(
        frameworks_df,
        x='complexity',
        y='effectiveness',
        size='cost',
        color='category',
        hover_name='name',
        title="Framework Complexity vs Effectiveness",
        labels={
            'complexity': 'Complexity Level',
            'effectiveness': 'Effectiveness Rating',
            'cost': 'Implementation Cost'
        }
    )
    
    fig.update_traces(marker=dict(sizemin=10))
    
    return fig

def create_implementation_timeline(frameworks_df, selected_frameworks):
    """Create a timeline chart for implementation duration"""
    
    if not selected_frameworks:
        return go.Figure().add_annotation(
            text="Please select frameworks to compare",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
    
    filtered_df = frameworks_df[frameworks_df['name'].isin(selected_frameworks)]
    
    fig = px.bar(
        filtered_df,
        x='name',
        y='time_to_implement',
        color='complexity',
        title="Implementation Timeline Comparison",
        labels={
            'time_to_implement': 'Time to Implement (months)',
            'name': 'Framework',
            'complexity': 'Complexity Level'
        }
    )
    
    fig.update_xaxes(tickangle=45)
    
    return fig

def create_cost_effectiveness_matrix(frameworks_df):
    """Create a 2x2 matrix showing cost vs effectiveness"""
    
    # Calculate median values for quadrant division
    median_cost = frameworks_df['cost'].median()
    median_effectiveness = frameworks_df['effectiveness'].median()
    
    # Create quadrant labels
    frameworks_df['quadrant'] = frameworks_df.apply(
        lambda row: get_quadrant_label(row['cost'], row['effectiveness'], median_cost, median_effectiveness),
        axis=1
    )
    
    fig = px.scatter(
        frameworks_df,
        x='cost',
        y='effectiveness',
        color='quadrant',
        hover_name='name',
        title="Cost vs Effectiveness Matrix",
        labels={
            'cost': 'Implementation Cost',
            'effectiveness': 'Effectiveness Rating'
        }
    )
    
    # Add quadrant lines
    fig.add_hline(y=median_effectiveness, line_dash="dash", line_color="gray")
    fig.add_vline(x=median_cost, line_dash="dash", line_color="gray")
    
    # Add quadrant annotations
    fig.add_annotation(x=1.5, y=4.5, text="High Value<br>(Low Cost, High Effect)", showarrow=False, bgcolor="lightgreen", opacity=0.7)
    fig.add_annotation(x=4.5, y=4.5, text="Premium<br>(High Cost, High Effect)", showarrow=False, bgcolor="lightyellow", opacity=0.7)
    fig.add_annotation(x=1.5, y=2.5, text="Low Impact<br>(Low Cost, Low Effect)", showarrow=False, bgcolor="lightcoral", opacity=0.7)
    fig.add_annotation(x=4.5, y=2.5, text="Poor Value<br>(High Cost, Low Effect)", showarrow=False, bgcolor="lightcoral", opacity=0.7)
    
    return fig

def get_quadrant_label(cost, effectiveness, median_cost, median_effectiveness):
    """Helper function to determine quadrant label"""
    if cost <= median_cost and effectiveness >= median_effectiveness:
        return "High Value"
    elif cost >= median_cost and effectiveness >= median_effectiveness:
        return "Premium"
    elif cost <= median_cost and effectiveness <= median_effectiveness:
        return "Low Impact"
    else:
        return "Poor Value"

def create_framework_network(frameworks_df, category_filter=None):
    """Create a network graph showing framework relationships"""
    
    if category_filter:
        filtered_df = frameworks_df[frameworks_df['category'] == category_filter]
    else:
        filtered_df = frameworks_df
    
    # Create network graph
    G = nx.Graph()
    
    # Add nodes (frameworks)
    for _, framework in filtered_df.iterrows():
        G.add_node(
            framework['name'],
            category=framework['category'],
            complexity=framework['complexity'],
            effectiveness=framework['effectiveness']
        )
    
    # Add edges based on similarity in characteristics
    frameworks_list = filtered_df.to_dict('records')
    for i, fw1 in enumerate(frameworks_list):
        for j, fw2 in enumerate(frameworks_list[i+1:], i+1):
            similarity = calculate_framework_similarity(fw1, fw2)
            if similarity > 0.7:  # Threshold for connection
                G.add_edge(fw1['name'], fw2['name'], weight=similarity)
    
    # Create plotly network visualization
    pos = nx.spring_layout(G, k=1, iterations=50)
    
    # Extract edges
    edge_x = []
    edge_y = []
    for edge in G.edges():
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
    
    # Extract nodes
    node_x = []
    node_y = []
    node_text = []
    node_color = []
    
    for node in G.nodes():
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)
        node_text.append(node)
        node_color.append(G.nodes[node]['effectiveness'])
    
    # Create figure
    fig = go.Figure()
    
    # Add edges
    fig.add_trace(go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=1, color='#888'),
        hoverinfo='none',
        mode='lines'
    ))
    
    # Add nodes
    fig.add_trace(go.Scatter(
        x=node_x, y=node_y,
        mode='markers+text',
        hoverinfo='text',
        text=node_text,
        textposition="middle center",
        marker=dict(
            size=20,
            color=node_color,
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(title="Effectiveness")
        )
    ))
    
    fig.update_layout(
        title="Framework Relationship Network",
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20,l=5,r=5,t=40),
        annotations=[ dict(
            text="Frameworks are connected based on similarity in characteristics",
            showarrow=False,
            xref="paper", yref="paper",
            x=0.005, y=-0.002 ) ],
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    
    return fig

def calculate_framework_similarity(fw1, fw2):
    """Calculate similarity between two frameworks based on characteristics"""
    
    # Compare numerical characteristics
    complexity_diff = abs(fw1['complexity'] - fw2['complexity'])
    time_diff = abs(fw1['time_to_implement'] - fw2['time_to_implement'])
    cost_diff = abs(fw1['cost'] - fw2['cost'])
    effectiveness_diff = abs(fw1['effectiveness'] - fw2['effectiveness'])
    
    # Calculate similarity score (inverse of differences)
    max_diff = 5  # Maximum possible difference
    similarity = 1 - (complexity_diff + time_diff + cost_diff + effectiveness_diff) / (4 * max_diff)
    
    # Bonus for same category
    if fw1['category'] == fw2['category']:
        similarity += 0.2
    
    return max(0, min(1, similarity))

def create_comparative_radar(frameworks_df, selected_frameworks):
    """Create a comparative radar chart for multiple frameworks"""
    
    if not selected_frameworks:
        return go.Figure().add_annotation(
            text="Please select frameworks to compare",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
    
    filtered_df = frameworks_df[frameworks_df['name'].isin(selected_frameworks)]
    
    categories = ['Complexity', 'Time to Implement', 'Cost', 'Effectiveness']
    
    fig = go.Figure()
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#FF9FF3']
    
    for i, (_, framework) in enumerate(filtered_df.iterrows()):
        values = [
            framework['complexity'],
            framework['time_to_implement'],
            framework['cost'],
            framework['effectiveness']
        ]
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name=framework['name'],
            line_color=colors[i % len(colors)]
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 5]
            )),
        showlegend=True,
        title="Comparative Framework Analysis"
    )
    
    return fig

def create_overview_dashboard(frameworks_df):
    """Create an overview dashboard with multiple visualizations"""
    
    # Create subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Category Distribution', 'Complexity vs Effectiveness', 
                       'Implementation Cost Distribution', 'Time to Implement'),
        specs=[[{"type": "pie"}, {"type": "scatter"}],
               [{"type": "histogram"}, {"type": "box"}]]
    )
    
    # Pie chart for categories
    category_counts = frameworks_df['category'].value_counts()
    fig.add_trace(
        go.Pie(labels=category_counts.index, values=category_counts.values),
        row=1, col=1
    )
    
    # Scatter plot
    fig.add_trace(
        go.Scatter(
            x=frameworks_df['complexity'],
            y=frameworks_df['effectiveness'],
            mode='markers',
            text=frameworks_df['name'],
            marker=dict(size=8, color=frameworks_df['cost'], colorscale='Viridis')
        ),
        row=1, col=2
    )
    
    # Histogram for cost
    fig.add_trace(
        go.Histogram(x=frameworks_df['cost'], nbinsx=5),
        row=2, col=1
    )
    
    # Box plot for time to implement
    fig.add_trace(
        go.Box(y=frameworks_df['time_to_implement']),
        row=2, col=2
    )
    
    fig.update_layout(
        height=800,
        title_text="Business Frameworks Overview Dashboard",
        showlegend=False
    )
    
    return fig

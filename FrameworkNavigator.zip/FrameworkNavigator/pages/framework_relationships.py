import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import networkx as nx
import numpy as np
from data.frameworks_data import get_all_frameworks, get_framework_categories
from utils.visualization import create_framework_network, calculate_framework_similarity
from utils.analysis import perform_framework_clustering, find_similar_frameworks

def show_page():
    """Display the Framework Relationships page"""
    
    st.title("🕸️ Framework Relationships")
    st.markdown("Explore how business frameworks connect, complement, and relate to each other through interactive network visualizations.")
    
    # Load data
    frameworks_df = get_all_frameworks()
    categories = get_framework_categories()
    
    # Page layout tabs
    tab1, tab2, tab3, tab4 = st.tabs(["Network Visualization", "Similarity Analysis", "Framework Clusters", "Dependency Mapping"])
    
    with tab1:
        show_network_visualization(frameworks_df, categories)
    
    with tab2:
        show_similarity_analysis(frameworks_df)
    
    with tab3:
        show_framework_clusters(frameworks_df)
    
    with tab4:
        show_dependency_mapping(frameworks_df, categories)

def show_network_visualization(frameworks_df, categories):
    """Show interactive network visualization"""
    
    st.subheader("🌐 Framework Network Visualization")
    st.markdown("Explore how frameworks relate to each other based on their characteristics and usage patterns.")
    
    # Controls
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        # Category filter
        network_categories = st.multiselect(
            "Select categories to visualize:",
            categories,
            default=categories[:4],
            help="Choose which framework categories to include in the network"
        )
    
    with col2:
        # Similarity threshold
        similarity_threshold = st.slider(
            "Connection threshold:",
            min_value=0.5,
            max_value=0.9,
            value=0.7,
            step=0.05,
            help="Minimum similarity required to show connections between frameworks"
        )
    
    with col3:
        # Network layout options
        layout_type = st.selectbox(
            "Network layout:",
            ["spring", "circular", "shell", "random"],
            help="Choose how to arrange frameworks in the network"
        )
        
        show_labels = st.checkbox("Show framework labels", value=True)
    
    if not network_categories:
        st.warning("Please select at least one category to visualize.")
        return
    
    # Filter data
    filtered_df = frameworks_df[frameworks_df['category'].isin(network_categories)]
    
    if filtered_df.empty:
        st.warning("No frameworks found for selected categories.")
        return
    
    # Create network graph
    G = nx.Graph()
    
    # Add nodes
    for _, framework in filtered_df.iterrows():
        G.add_node(
            framework['name'],
            category=framework['category'],
            complexity=framework['complexity'],
            effectiveness=framework['effectiveness'],
            cost=framework['cost'],
            time_to_implement=framework['time_to_implement']
        )
    
    # Add edges based on similarity
    frameworks_list = filtered_df.to_dict('records')
    edge_weights = []
    
    for i, fw1 in enumerate(frameworks_list):
        for j, fw2 in enumerate(frameworks_list[i+1:], i+1):
            similarity = calculate_framework_similarity(fw1, fw2)
            if similarity >= similarity_threshold:
                G.add_edge(fw1['name'], fw2['name'], weight=similarity)
                edge_weights.append(similarity)
    
    if len(G.edges()) == 0:
        st.warning(f"No connections found with threshold {similarity_threshold}. Try lowering the threshold.")
        return
    
    # Create layout
    if layout_type == "spring":
        pos = nx.spring_layout(G, k=1, iterations=50)
    elif layout_type == "circular":
        pos = nx.circular_layout(G)
    elif layout_type == "shell":
        pos = nx.shell_layout(G)
    else:
        pos = nx.random_layout(G)
    
    # Create plotly visualization
    edge_x = []
    edge_y = []
    edge_weights_plot = []
    
    for edge in G.edges(data=True):
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
        edge_weights_plot.extend([edge[2]['weight'], edge[2]['weight'], None])
    
    # Extract node information
    node_x = []
    node_y = []
    node_text = []
    node_color = []
    node_size = []
    node_hover = []
    
    for node in G.nodes(data=True):
        x, y = pos[node[0]]
        node_x.append(x)
        node_y.append(y)
        node_text.append(node[0] if show_labels else "")
        node_color.append(node[1]['effectiveness'])
        node_size.append(10 + node[1]['complexity'] * 5)  # Size based on complexity
        
        # Hover information
        hover_text = f"""
        <b>{node[0]}</b><br>
        Category: {node[1]['category']}<br>
        Complexity: {node[1]['complexity']}/5<br>
        Effectiveness: {node[1]['effectiveness']}/5<br>
        Cost: {node[1]['cost']}/5<br>
        Implementation Time: {node[1]['time_to_implement']}/5<br>
        Connections: {len(list(G.neighbors(node[0])))}
        """
        node_hover.append(hover_text)
    
    # Create figure
    fig = go.Figure()
    
    # Add edges
    if edge_x:
        fig.add_trace(go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=1, color='rgba(125,125,125,0.5)'),
            hoverinfo='none',
            mode='lines',
            name='Connections'
        ))
    
    # Add nodes
    fig.add_trace(go.Scatter(
        x=node_x, y=node_y,
        mode='markers+text',
        hoverinfo='text',
        hovertext=node_hover,
        text=node_text,
        textposition="middle center",
        textfont=dict(size=8),
        marker=dict(
            size=node_size,
            color=node_color,
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(
                title="Effectiveness"
            ),
            line=dict(width=1, color='white')
        ),
        name='Frameworks'
    ))
    
    fig.update_layout(
        title=f"Framework Relationship Network ({len(G.nodes())} frameworks, {len(G.edges())} connections)",
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20, l=5, r=5, t=40),
        annotations=[
            dict(
                text=f"Similarity threshold: {similarity_threshold} | Layout: {layout_type}",
                showarrow=False,
                xref="paper", yref="paper",
                x=0.005, y=-0.002
            )
        ],
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        height=600
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Network statistics
    st.markdown("#### 📊 Network Statistics")
    
    col4, col5, col6, col7 = st.columns(4)
    
    with col4:
        st.metric("Total Frameworks", len(list(G.nodes())))
    
    with col5:
        st.metric("Total Connections", len(list(G.edges())))
    
    with col6:
        nodes_list = list(G.nodes())
        avg_connections = np.mean([len(list(G.neighbors(node))) for node in nodes_list]) if nodes_list else 0
        st.metric("Avg Connections", f"{avg_connections:.1f}")
    
    with col7:
        density = nx.density(G) if nodes_list else 0
        st.metric("Network Density", f"{density:.3f}")
    
    # Most connected frameworks
    if nodes_list:
        st.markdown("#### 🌟 Most Connected Frameworks")
        
        connections_data = []
        for node in nodes_list:
            connections_data.append({
                'Framework': node,
                'Connections': len(list(G.neighbors(node))),
                'Category': G.nodes[node]['category']
            })
        
        connections_df = pd.DataFrame(connections_data).sort_values('Connections', ascending=False)
        
        st.dataframe(
            connections_df.head(10),
            column_config={
                'Framework': 'Framework Name',
                'Connections': st.column_config.ProgressColumn('Number of Connections', min_value=0, max_value=int(connections_df['Connections'].max())),
                'Category': 'Category'
            },
            hide_index=True,
            use_container_width=True
        )

def show_similarity_analysis(frameworks_df):
    """Show detailed similarity analysis"""
    
    st.subheader("🔍 Framework Similarity Analysis")
    st.markdown("Analyze how similar frameworks are to each other based on various characteristics.")
    
    # Framework selection
    col1, col2 = st.columns([1, 1])
    
    with col1:
        reference_framework = st.selectbox(
            "Select reference framework:",
            frameworks_df['name'].tolist(),
            help="Choose a framework to find similar ones"
        )
        
        num_similar = st.slider(
            "Number of similar frameworks:",
            min_value=5,
            max_value=15,
            value=10,
            help="How many similar frameworks to display"
        )
    
    with col2:
        similarity_criteria = st.multiselect(
            "Similarity criteria:",
            ["Complexity", "Implementation Time", "Cost", "Effectiveness", "Category"],
            default=["Complexity", "Implementation Time", "Cost", "Effectiveness"],
            help="Choose which characteristics to consider for similarity"
        )
    
    if reference_framework and similarity_criteria:
        # Find similar frameworks
        similar_frameworks = find_similar_frameworks(reference_framework, frameworks_df, n_similar=num_similar)
        
        if similar_frameworks:
            # Create similarity matrix visualization
            st.markdown("#### 📊 Similarity Heatmap")
            
            # Prepare data for heatmap
            ref_framework_data = frameworks_df[frameworks_df['name'] == reference_framework].iloc[0]
            similarity_data = []
            
            # Add reference framework
            similarity_data.append({
                'Framework': reference_framework,
                'Complexity': ref_framework_data['complexity'],
                'Time': ref_framework_data['time_to_implement'],
                'Cost': ref_framework_data['cost'],
                'Effectiveness': ref_framework_data['effectiveness'],
                'Similarity': 1.0
            })
            
            # Add similar frameworks
            for sim_fw in similar_frameworks:
                similarity_data.append({
                    'Framework': sim_fw['name'],
                    'Complexity': sim_fw['complexity'],
                    'Time': sim_fw['time_to_implement'],
                    'Cost': sim_fw['cost'],
                    'Effectiveness': sim_fw['effectiveness'],
                    'Similarity': sim_fw['similarity']
                })
            
            similarity_df = pd.DataFrame(similarity_data)
            
            # Create heatmap
            characteristics_matrix = similarity_df.set_index('Framework')[['Complexity', 'Time', 'Cost', 'Effectiveness']]
            
            fig_heatmap = px.imshow(
                characteristics_matrix.T,
                labels=dict(x="Framework", y="Characteristic", color="Rating"),
                x=characteristics_matrix.index,
                y=['Complexity', 'Implementation Time', 'Cost', 'Effectiveness'],
                color_continuous_scale='RdYlGn',
                title=f"Characteristics Comparison with {reference_framework}"
            )
            
            fig_heatmap.update_layout(height=300)
            st.plotly_chart(fig_heatmap, use_container_width=True)
            
            # Similarity scores visualization
            st.markdown("#### 📈 Similarity Scores")
            
            similarity_scores_df = pd.DataFrame(similar_frameworks)
            
            fig_similarity = px.bar(
                similarity_scores_df,
                x='similarity',
                y='name',
                orientation='h',
                color='category',
                title=f"Frameworks Similar to {reference_framework}",
                labels={'similarity': 'Similarity Score', 'name': 'Framework'}
            )
            fig_similarity.update_layout(height=max(400, len(similar_frameworks) * 30))
            st.plotly_chart(fig_similarity, use_container_width=True)
            
            # Detailed similarity table
            st.markdown("#### 📋 Detailed Similarity Analysis")
            
            st.dataframe(
                similarity_scores_df[['name', 'category', 'similarity', 'complexity', 'time_to_implement', 'cost', 'effectiveness']],
                column_config={
                    'name': 'Framework Name',
                    'category': 'Category',
                    'similarity': st.column_config.ProgressColumn('Similarity Score', min_value=0, max_value=1),
                    'complexity': st.column_config.ProgressColumn('Complexity', min_value=1, max_value=5),
                    'time_to_implement': st.column_config.ProgressColumn('Implementation Time', min_value=1, max_value=5),
                    'cost': st.column_config.ProgressColumn('Cost', min_value=1, max_value=5),
                    'effectiveness': st.column_config.ProgressColumn('Effectiveness', min_value=1, max_value=5)
                },
                hide_index=True,
                use_container_width=True
            )

def show_framework_clusters(frameworks_df):
    """Show framework clustering analysis"""
    
    st.subheader("🎯 Framework Clusters")
    st.markdown("Discover groups of frameworks with similar characteristics using machine learning clustering.")
    
    # Clustering controls
    col1, col2 = st.columns([1, 1])
    
    with col1:
        num_clusters = st.slider(
            "Number of clusters:",
            min_value=3,
            max_value=8,
            value=5,
            help="How many clusters to create"
        )
    
    with col2:
        cluster_features = st.multiselect(
            "Features for clustering:",
            ["complexity", "time_to_implement", "cost", "effectiveness"],
            default=["complexity", "time_to_implement", "cost", "effectiveness"],
            help="Choose which characteristics to use for clustering"
        )
    
    if not cluster_features:
        st.warning("Please select at least one feature for clustering.")
        return
    
    # Perform clustering
    clustered_df, cluster_summary = perform_framework_clustering(frameworks_df, n_clusters=num_clusters)
    
    # Cluster visualization
    st.markdown("#### 📊 Cluster Visualization")
    
    # Use first two features for 2D visualization
    if len(cluster_features) >= 2:
        fig_cluster = px.scatter(
            clustered_df,
            x=cluster_features[0],
            y=cluster_features[1],
            color='cluster',
            hover_name='name',
            title=f"Framework Clusters ({cluster_features[0]} vs {cluster_features[1]})",
            labels={
                cluster_features[0]: cluster_features[0].replace('_', ' ').title(),
                cluster_features[1]: cluster_features[1].replace('_', ' ').title()
            }
        )
        
        st.plotly_chart(fig_cluster, use_container_width=True)
    
    # Cluster characteristics
    st.markdown("#### 📈 Cluster Characteristics")
    
    # Create radar chart for each cluster
    cluster_colors = px.colors.qualitative.Set1[:num_clusters]
    
    fig_radar = go.Figure()
    
    for cluster_id in range(num_clusters):
        cluster_data = cluster_summary.loc[cluster_id]
        
        fig_radar.add_trace(go.Scatterpolar(
            r=[cluster_data[feat] for feat in cluster_features],
            theta=[feat.replace('_', ' ').title() for feat in cluster_features],
            fill='toself',
            name=f'Cluster {cluster_id}',
            line_color=cluster_colors[cluster_id]
        ))
    
    fig_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 5]
            )),
        showlegend=True,
        title="Average Characteristics by Cluster"
    )
    
    st.plotly_chart(fig_radar, use_container_width=True)
    
    # Cluster summary table
    st.markdown("#### 📋 Cluster Summary")
    
    cluster_summary_display = cluster_summary.copy()
    cluster_summary_display.index = [f"Cluster {i}" for i in cluster_summary_display.index]
    
    st.dataframe(
        cluster_summary_display,
        column_config={
            'complexity': st.column_config.NumberColumn('Avg Complexity', format="%.2f"),
            'time_to_implement': st.column_config.NumberColumn('Avg Implementation Time', format="%.2f"),
            'cost': st.column_config.NumberColumn('Avg Cost', format="%.2f"),
            'effectiveness': st.column_config.NumberColumn('Avg Effectiveness', format="%.2f")
        },
        use_container_width=True
    )
    
    # Frameworks by cluster
    st.markdown("#### 🗂️ Frameworks by Cluster")
    
    for cluster_id in range(num_clusters):
        cluster_frameworks = clustered_df[clustered_df['cluster'] == cluster_id]
        
        with st.expander(f"Cluster {cluster_id} ({len(cluster_frameworks)} frameworks)", expanded=False):
            # Cluster description
            avg_complexity = cluster_frameworks['complexity'].mean()
            avg_cost = cluster_frameworks['cost'].mean()
            avg_time = cluster_frameworks['time_to_implement'].mean()
            avg_effectiveness = cluster_frameworks['effectiveness'].mean()
            
            st.write(f"**Cluster Profile:** ")
            if avg_complexity <= 2.5:
                st.write("• Low complexity frameworks")
            elif avg_complexity >= 3.5:
                st.write("• High complexity frameworks")
            else:
                st.write("• Medium complexity frameworks")
            
            if avg_cost <= 2.5:
                st.write("• Low cost implementation")
            elif avg_cost >= 3.5:
                st.write("• High cost implementation")
            else:
                st.write("• Medium cost implementation")
            
            if avg_effectiveness >= 4:
                st.write("• High effectiveness frameworks")
            elif avg_effectiveness <= 3:
                st.write("• Moderate effectiveness frameworks")
            else:
                st.write("• Good effectiveness frameworks")
            
            # Framework list
            st.dataframe(
                cluster_frameworks[['name', 'category', 'complexity', 'time_to_implement', 'cost', 'effectiveness']],
                column_config={
                    'name': 'Framework Name',
                    'category': 'Category',
                    'complexity': 'Complexity',
                    'time_to_implement': 'Implementation Time',
                    'cost': 'Cost',
                    'effectiveness': 'Effectiveness'
                },
                hide_index=True,
                use_container_width=True
            )

def show_dependency_mapping(frameworks_df, categories):
    """Show framework dependencies and relationships"""
    
    st.subheader("🔗 Framework Dependencies & Relationships")
    st.markdown("Explore which frameworks work best together and their implementation dependencies.")
    
    # Create dependency mapping based on categories and characteristics
    dependency_map = create_dependency_map(frameworks_df, categories)
    
    # Dependency visualization controls
    col1, col2 = st.columns([1, 1])
    
    with col1:
        selected_category = st.selectbox(
            "Focus on category:",
            ["All Categories"] + categories,
            help="Focus the dependency map on a specific category"
        )
    
    with col2:
        dependency_type = st.selectbox(
            "Dependency type:",
            ["Implementation Order", "Complementary", "Similar Purpose", "Cross-Category"],
            help="Type of relationship to visualize"
        )
    
    # Create dependency network
    st.markdown("#### 🕸️ Dependency Network")
    
    G_dep = nx.DiGraph()
    
    # Add nodes and edges based on dependency type
    if dependency_type == "Implementation Order":
        create_implementation_order_network(G_dep, frameworks_df, selected_category)
    elif dependency_type == "Complementary":
        create_complementary_network(G_dep, frameworks_df, selected_category)
    elif dependency_type == "Similar Purpose":
        create_similar_purpose_network(G_dep, frameworks_df, selected_category)
    else:  # Cross-Category
        create_cross_category_network(G_dep, frameworks_df, categories)
    
    if len(G_dep.nodes()) == 0:
        st.info("No dependencies found for the selected criteria.")
        return
    
    # Visualize dependency network
    pos = nx.spring_layout(G_dep, k=2, iterations=50)
    
    # Create directed network visualization
    edge_x = []
    edge_y = []
    
    for edge in G_dep.edges():
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
    
    # Node information
    node_x = []
    node_y = []
    node_text = []
    node_color = []
    node_hover = []
    
    for node in G_dep.nodes(data=True):
        x, y = pos[node[0]]
        node_x.append(x)
        node_y.append(y)
        node_text.append(node[0])
        
        # Get framework data
        fw_data = frameworks_df[frameworks_df['name'] == node[0]].iloc[0]
        node_color.append(fw_data['effectiveness'])
        
        # Dependencies
        predecessors = list(G_dep.predecessors(node[0]))
        successors = list(G_dep.successors(node[0]))
        
        hover_text = f"""
        <b>{node[0]}</b><br>
        Category: {fw_data['category']}<br>
        Prerequisites: {len(predecessors)}<br>
        Enables: {len(successors)}<br>
        Effectiveness: {fw_data['effectiveness']}/5
        """
        node_hover.append(hover_text)
    
    # Create figure
    fig_dep = go.Figure()
    
    # Add edges (dependencies)
    fig_dep.add_trace(go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=2, color='rgba(125,125,125,0.8)'),
        hoverinfo='none',
        mode='lines',
        name='Dependencies'
    ))
    
    # Add nodes
    fig_dep.add_trace(go.Scatter(
        x=node_x, y=node_y,
        mode='markers+text',
        hoverinfo='text',
        hovertext=node_hover,
        text=node_text,
        textposition="middle center",
        textfont=dict(size=10),
        marker=dict(
            size=20,
            color=node_color,
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(title="Effectiveness"),
            line=dict(width=2, color='white')
        ),
        name='Frameworks'
    ))
    
    fig_dep.update_layout(
        title=f"Framework Dependencies: {dependency_type}",
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20, l=5, r=5, t=40),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        height=600
    )
    
    st.plotly_chart(fig_dep, use_container_width=True)
    
    # Dependency analysis
    st.markdown("#### 📊 Dependency Analysis")
    
    col3, col4, col5 = st.columns(3)
    
    with col3:
        # Entry points (no prerequisites)
        entry_points = [node for node in G_dep.nodes() if G_dep.in_degree(node) == 0]
        st.metric("Entry Points", len(entry_points))
        if entry_points:
            st.write("**Starting frameworks:**")
            for ep in entry_points[:5]:
                st.write(f"• {ep}")
    
    with col4:
        # Hub frameworks (high connectivity)
        hub_frameworks = sorted(G_dep.nodes(), key=lambda x: G_dep.degree(x), reverse=True)[:5]
        st.metric("Most Connected", len(hub_frameworks))
        if hub_frameworks:
            st.write("**Hub frameworks:**")
            for hf in hub_frameworks:
                connections = G_dep.degree(hf)
                st.write(f"• {hf} ({connections} connections)")
    
    with col5:
        # End points (enable many others)
        end_points = [node for node in G_dep.nodes() if G_dep.out_degree(node) == 0]
        st.metric("End Points", len(end_points))
        if end_points:
            st.write("**Terminal frameworks:**")
            for ep in end_points[:5]:
                st.write(f"• {ep}")

def create_dependency_map(frameworks_df, categories):
    """Create a dependency map between frameworks"""
    # This is a simplified dependency map - in practice, this would be more sophisticated
    dependency_map = {}
    
    for category in categories:
        cat_frameworks = frameworks_df[frameworks_df['category'] == category]['name'].tolist()
        dependency_map[category] = cat_frameworks
    
    return dependency_map

def create_implementation_order_network(G, frameworks_df, selected_category):
    """Create network based on implementation order (complexity/time based)"""
    
    if selected_category != "All Categories":
        df = frameworks_df[frameworks_df['category'] == selected_category]
    else:
        df = frameworks_df.head(20)  # Limit for visualization
    
    # Sort by implementation difficulty (complexity + time)
    df = df.copy()
    df['difficulty'] = df['complexity'] + df['time_to_implement']
    df = df.sort_values('difficulty')
    
    # Add nodes
    for _, framework in df.iterrows():
        G.add_node(framework['name'])
    
    # Add edges based on implementation order
    frameworks_list = df['name'].tolist()
    for i in range(len(frameworks_list) - 1):
        # Simple frameworks enable more complex ones
        if df.iloc[i]['difficulty'] < df.iloc[i+1]['difficulty']:
            G.add_edge(frameworks_list[i], frameworks_list[i+1])

def create_complementary_network(G, frameworks_df, selected_category):
    """Create network of complementary frameworks"""
    
    if selected_category != "All Categories":
        df = frameworks_df[frameworks_df['category'] == selected_category]
    else:
        df = frameworks_df.head(15)  # Limit for visualization
    
    # Add nodes
    for _, framework in df.iterrows():
        G.add_node(framework['name'])
    
    # Add edges for complementary frameworks (different strengths)
    frameworks_list = df.to_dict('records')
    for i, fw1 in enumerate(frameworks_list):
        for j, fw2 in enumerate(frameworks_list[i+1:], i+1):
            # Complementary if they have different strength profiles
            if are_complementary(fw1, fw2):
                G.add_edge(fw1['name'], fw2['name'])

def create_similar_purpose_network(G, frameworks_df, selected_category):
    """Create network of frameworks with similar purposes"""
    
    if selected_category != "All Categories":
        df = frameworks_df[frameworks_df['category'] == selected_category]
    else:
        df = frameworks_df.head(15)  # Limit for visualization
    
    # Add nodes
    for _, framework in df.iterrows():
        G.add_node(framework['name'])
    
    # Add edges for similar frameworks
    frameworks_list = df.to_dict('records')
    for i, fw1 in enumerate(frameworks_list):
        for j, fw2 in enumerate(frameworks_list[i+1:], i+1):
            similarity = calculate_framework_similarity(fw1, fw2)
            if similarity > 0.8:  # High similarity threshold
                G.add_edge(fw1['name'], fw2['name'])

def create_cross_category_network(G, frameworks_df, categories):
    """Create network showing cross-category relationships"""
    
    # Select representative frameworks from each category
    selected_frameworks = []
    for category in categories[:6]:  # Limit categories for visualization
        cat_frameworks = frameworks_df[frameworks_df['category'] == category]
        if not cat_frameworks.empty:
            # Select highest effectiveness framework from each category
            best_fw = cat_frameworks.loc[cat_frameworks['effectiveness'].idxmax()]
            selected_frameworks.append(best_fw)
    
    # Add nodes
    for framework in selected_frameworks:
        G.add_node(framework['name'])
    
    # Add edges between frameworks from different categories that complement each other
    for i, fw1 in enumerate(selected_frameworks):
        for j, fw2 in enumerate(selected_frameworks[i+1:], i+1):
            if fw1['category'] != fw2['category'] and are_complementary(fw1.to_dict(), fw2.to_dict()):
                G.add_edge(fw1['name'], fw2['name'])

def are_complementary(fw1, fw2):
    """Determine if two frameworks are complementary"""
    
    # Frameworks are complementary if they have different strengths
    complexity_diff = abs(fw1['complexity'] - fw2['complexity'])
    cost_diff = abs(fw1['cost'] - fw2['cost'])
    time_diff = abs(fw1['time_to_implement'] - fw2['time_to_implement'])
    
    # High difference in characteristics suggests complementarity
    total_diff = complexity_diff + cost_diff + time_diff
    
    # Also consider if both have high effectiveness
    both_effective = fw1['effectiveness'] >= 4 and fw2['effectiveness'] >= 4
    
    return total_diff >= 4 and both_effective

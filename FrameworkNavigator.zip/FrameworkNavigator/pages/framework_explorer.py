import streamlit as st
import pandas as pd
import plotly.express as px
from data.frameworks_data import get_all_frameworks, get_framework_categories
from utils.visualization import create_framework_radar_chart, create_cost_effectiveness_matrix
from utils.analysis import calculate_framework_score, find_similar_frameworks, calculate_roi_estimation

def show_page():
    """Display the Framework Explorer page"""
    
    st.title("🔍 Framework Explorer")
    st.markdown("Dive deep into individual frameworks with interactive parameters and real-time analysis.")
    
    try:
        # Load data
        frameworks_df = get_all_frameworks()
        categories = get_framework_categories()
        
        if frameworks_df.empty:
            st.error("No framework data available.")
            return
            
        st.success(f"Loaded {len(frameworks_df)} frameworks successfully!")
    except Exception as e:
        st.error(f"Error loading framework data: {str(e)}")
        return
    
    # Sidebar filters
    st.sidebar.header("🎛️ Framework Filters")
    
    # Category filter
    selected_categories = st.sidebar.multiselect(
        "Select Categories:",
        categories,
        default=categories[:3]
    )
    
    # Complexity filter
    complexity_range = st.sidebar.slider(
        "Complexity Level:",
        min_value=1,
        max_value=5,
        value=(1, 5),
        help="Filter frameworks by complexity level"
    )
    
    # Effectiveness filter
    effectiveness_range = st.sidebar.slider(
        "Effectiveness Rating:",
        min_value=1,
        max_value=5,
        value=(3, 5),
        help="Filter frameworks by effectiveness rating"
    )
    
    # Apply filters
    filtered_df = frameworks_df[
        (frameworks_df['category'].isin(selected_categories)) &
        (frameworks_df['complexity'] >= complexity_range[0]) &
        (frameworks_df['complexity'] <= complexity_range[1]) &
        (frameworks_df['effectiveness'] >= effectiveness_range[0]) &
        (frameworks_df['effectiveness'] <= effectiveness_range[1])
    ]
    
    # Main content
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("📋 Select Framework")
        
        # Framework selection
        if filtered_df.empty:
            st.warning("No frameworks match your filters. Please adjust the criteria.")
            return
        
        framework_names = filtered_df['name'].tolist()
        selected_framework_name = st.selectbox(
            "Choose a framework:",
            framework_names,
            help="Select a framework to explore in detail"
        )
        
        # Get selected framework data
        selected_framework = filtered_df[filtered_df['name'] == selected_framework_name].iloc[0]
        
        # Display framework details
        with st.expander("📖 Framework Details", expanded=True):
            st.write(f"**Category:** {selected_framework['category']}")
            st.write(f"**Core Function:** {selected_framework['core_function']}")
            st.write(f"**Typical Uses:** {selected_framework['typical_uses']}")
            
            # Display current ratings
            st.write("**Current Ratings:**")
            st.write(f"• Complexity: {selected_framework['complexity']}/5")
            st.write(f"• Time to Implement: {selected_framework['time_to_implement']}/5")
            st.write(f"• Cost: {selected_framework['cost']}/5")
            st.write(f"• Effectiveness: {selected_framework['effectiveness']}/5")
    
    with col2:
        st.subheader("📊 Interactive Analysis")
        
        # Parameter adjustment section
        st.markdown("#### 🎚️ Adjust Parameters")
        
        col2a, col2b = st.columns(2)
        
        with col2a:
            adj_complexity = st.slider(
                "Complexity Level",
                min_value=1,
                max_value=5,
                value=int(selected_framework['complexity']),
                help="Adjust complexity for your context"
            )
            
            adj_time = st.slider(
                "Time to Implement (months)",
                min_value=1,
                max_value=5,
                value=int(selected_framework['time_to_implement']),
                help="Adjust implementation time for your context"
            )
        
        with col2b:
            adj_cost = st.slider(
                "Implementation Cost",
                min_value=1,
                max_value=5,
                value=int(selected_framework['cost']),
                help="Adjust cost level for your context"
            )
            
            adj_effectiveness = st.slider(
                "Effectiveness Rating",
                min_value=1,
                max_value=5,
                value=int(selected_framework['effectiveness']),
                help="Adjust effectiveness for your context"
            )
    
    # Real-time visualizations
    st.markdown("---")
    st.subheader("📈 Real-time Visualizations")
    
    # Create adjusted parameters dictionary
    adjusted_params = {
        'complexity': adj_complexity,
        'time_to_implement': adj_time,
        'cost': adj_cost,
        'effectiveness': adj_effectiveness
    }
    
    # Create three columns for visualizations
    col3, col4, col5 = st.columns(3)
    
    with col3:
        # Radar chart with adjusted parameters
        radar_fig = create_framework_radar_chart(selected_framework.to_dict(), adjusted_params)
        st.plotly_chart(radar_fig, use_container_width=True)
        
        # Calculate and display adjusted score
        adjusted_framework = selected_framework.copy()
        adjusted_framework['complexity'] = adj_complexity
        adjusted_framework['time_to_implement'] = adj_time
        adjusted_framework['cost'] = adj_cost
        adjusted_framework['effectiveness'] = adj_effectiveness
        
        adjusted_score = calculate_framework_score(adjusted_framework)
        original_score = calculate_framework_score(selected_framework)
        
        st.metric(
            "Framework Score",
            f"{adjusted_score:.1f}",
            f"{adjusted_score - original_score:.1f}",
            help="Composite score based on adjusted parameters"
        )
    
    with col4:
        # Cost vs Effectiveness comparison
        comparison_data = pd.DataFrame({
            'Framework': ['Original', 'Adjusted'],
            'Cost': [selected_framework['cost'], adj_cost],
            'Effectiveness': [selected_framework['effectiveness'], adj_effectiveness],
            'Type': ['Original', 'Adjusted']
        })
        
        cost_eff_fig = px.scatter(
            comparison_data,
            x='Cost',
            y='Effectiveness',
            color='Type',
            size=[10, 15],
            title="Cost vs Effectiveness",
            labels={'Cost': 'Implementation Cost', 'Effectiveness': 'Effectiveness Rating'}
        )
        cost_eff_fig.update_traces(marker=dict(sizemin=10))
        st.plotly_chart(cost_eff_fig, use_container_width=True)
    
    with col5:
        # Implementation timeline comparison
        timeline_data = pd.DataFrame({
            'Aspect': ['Original', 'Adjusted'],
            'Months': [selected_framework['time_to_implement'], adj_time],
            'Complexity': [selected_framework['complexity'], adj_complexity]
        })
        
        timeline_fig = px.bar(
            timeline_data,
            x='Aspect',
            y='Months',
            color='Complexity',
            title="Implementation Timeline",
            labels={'Months': 'Time to Implement (months)'}
        )
        st.plotly_chart(timeline_fig, use_container_width=True)
    
    # ROI Analysis
    st.markdown("---")
    st.subheader("💰 ROI Analysis")
    
    col6, col7 = st.columns([1, 2])
    
    with col6:
        st.markdown("#### Investment Parameters")
        
        expected_benefit = st.number_input(
            "Expected Annual Benefit ($)",
            min_value=1000,
            max_value=10000000,
            value=100000,
            step=10000,
            help="Expected annual monetary benefit from implementing this framework"
        )
        
        cost_multiplier = st.number_input(
            "Cost Multiplier ($)",
            min_value=1000,
            max_value=100000,
            value=10000,
            step=1000,
            help="Multiplier to convert cost rating to actual dollars"
        )
    
    with col7:
        # Calculate ROI with adjusted parameters
        roi_data = calculate_roi_estimation(
            adjusted_framework.to_dict(),
            {
                'expected_benefit': expected_benefit,
                'cost_multiplier': cost_multiplier
            }
        )
        
        st.markdown("#### ROI Metrics")
        
        col7a, col7b, col7c = st.columns(3)
        
        with col7a:
            st.metric(
                "ROI",
                f"{roi_data['roi_percentage']:.1f}%",
                help="Return on Investment percentage"
            )
        
        with col7b:
            st.metric(
                "Payback Period",
                f"{roi_data['payback_months']:.1f} months",
                help="Time to recover the initial investment"
            )
        
        with col7c:
            st.metric(
                "Net Annual Value",
                f"${roi_data['net_annual_value']:,.0f}",
                help="Annual benefit minus annualized implementation cost"
            )
        
        # ROI breakdown
        st.markdown("**Financial Breakdown:**")
        st.write(f"• Implementation Cost: ${roi_data['implementation_cost']:,.0f}")
        st.write(f"• Annual Benefit: ${roi_data['annual_benefit']:,.0f}")
        st.write(f"• Net Annual Value: ${roi_data['net_annual_value']:,.0f}")
    
    # Similar Frameworks
    st.markdown("---")
    st.subheader("🔗 Similar Frameworks")
    
    similar_frameworks = find_similar_frameworks(selected_framework_name, frameworks_df, n_similar=5)
    
    if similar_frameworks:
        similar_df = pd.DataFrame(similar_frameworks)
        
        # Display similar frameworks in an interactive table
        st.dataframe(
            similar_df[['name', 'category', 'similarity', 'complexity', 'time_to_implement', 'cost', 'effectiveness']],
            column_config={
                'name': 'Framework Name',
                'category': 'Category',
                'similarity': st.column_config.ProgressColumn(
                    'Similarity Score',
                    help='Similarity to selected framework',
                    min_value=0,
                    max_value=1
                ),
                'complexity': st.column_config.NumberColumn('Complexity', help='1-5 scale'),
                'time_to_implement': st.column_config.NumberColumn('Time (months)', help='1-5 scale'),
                'cost': st.column_config.NumberColumn('Cost', help='1-5 scale'),
                'effectiveness': st.column_config.NumberColumn('Effectiveness', help='1-5 scale')
            },
            hide_index=True,
            use_container_width=True
        )
    else:
        st.info("No similar frameworks found.")
    
    # Export functionality
    st.markdown("---")
    st.subheader("📤 Export Analysis")
    
    if st.button("Generate Report", type="primary"):
        # Create summary report
        report_data = {
            'Framework': selected_framework_name,
            'Category': selected_framework['category'],
            'Adjusted_Complexity': adj_complexity,
            'Adjusted_Time': adj_time,
            'Adjusted_Cost': adj_cost,
            'Adjusted_Effectiveness': adj_effectiveness,
            'Framework_Score': adjusted_score,
            'ROI_Percentage': roi_data['roi_percentage'],
            'Payback_Months': roi_data['payback_months'],
            'Expected_Annual_Benefit': expected_benefit,
            'Implementation_Cost': roi_data['implementation_cost']
        }
        
        # Convert to dataframe for download
        report_df = pd.DataFrame([report_data])
        
        # Create download button
        csv = report_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Analysis Report (CSV)",
            data=csv,
            file_name=f"{selected_framework_name.replace(' ', '_')}_analysis.csv",
            mime="text/csv"
        )
        
        st.success("Report generated successfully!")

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from data.frameworks_data import get_all_frameworks, get_industry_framework_mapping
from utils.recommendations import get_industry_recommendations, get_smart_recommendations, get_framework_alternatives, get_complementary_frameworks, get_implementation_roadmap
from utils.analysis import calculate_framework_score

def show_page():
    """Display the Industry Recommendations page"""
    
    st.title("🏭 Industry Recommendations")
    st.markdown("Get personalized framework recommendations based on your industry, company profile, and specific needs.")
    
    # Load data
    frameworks_df = get_all_frameworks()
    industry_mapping = get_industry_framework_mapping()
    
    # Main recommendation modes
    recommendation_mode = st.radio(
        "Choose recommendation approach:",
        ["Industry-Based Recommendations", "Smart Personalized Recommendations", "Framework Alternatives"],
        help="Select how you'd like to receive framework recommendations"
    )
    
    if recommendation_mode == "Industry-Based Recommendations":
        show_industry_recommendations(frameworks_df, industry_mapping)
    elif recommendation_mode == "Smart Personalized Recommendations":
        show_smart_recommendations(frameworks_df)
    else:
        show_framework_alternatives(frameworks_df)

def show_industry_recommendations(frameworks_df, industry_mapping):
    """Show industry-based recommendations"""
    
    st.subheader("🎯 Industry-Specific Framework Recommendations")
    st.markdown("Select your industry to see frameworks commonly used and proven effective in your sector.")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        # Industry selection
        industries = list(industry_mapping.keys())
        selected_industry = st.selectbox(
            "Select your industry:",
            industries,
            help="Choose the industry that best matches your organization"
        )
        
        # Additional filters
        st.markdown("#### 🔧 Refine Recommendations")
        
        priority_factor = st.selectbox(
            "What's most important?",
            ["Effectiveness", "Low Cost", "Quick Implementation", "Low Complexity"],
            help="Primary factor for ranking recommendations"
        )
        
        max_frameworks = st.slider(
            "Number of recommendations:",
            min_value=3,
            max_value=12,
            value=8,
            help="How many framework recommendations to show"
        )
    
    with col2:
        if selected_industry:
            # Get industry recommendations
            recommended_frameworks, error = get_industry_recommendations(selected_industry, top_n=max_frameworks)
            
            if error:
                st.error(error)
                return
            
            if recommended_frameworks.empty:
                st.warning(f"No recommendations found for {selected_industry}")
                return
            
            # Apply priority sorting
            if priority_factor == "Effectiveness":
                recommended_frameworks = recommended_frameworks.sort_values('effectiveness', ascending=False)
            elif priority_factor == "Low Cost":
                recommended_frameworks = recommended_frameworks.sort_values('cost', ascending=True)
            elif priority_factor == "Quick Implementation":
                recommended_frameworks = recommended_frameworks.sort_values('time_to_implement', ascending=True)
            elif priority_factor == "Low Complexity":
                recommended_frameworks = recommended_frameworks.sort_values('complexity', ascending=True)
            
            # Display recommendations
            st.markdown(f"#### Top Recommendations for {selected_industry}")
            
            # Create ranking visualization
            ranking_fig = px.bar(
                recommended_frameworks.head(max_frameworks),
                x='score',
                y='name',
                orientation='h',
                color='effectiveness',
                title=f"Framework Rankings for {selected_industry}",
                labels={'score': 'Recommendation Score', 'name': 'Framework'},
                color_continuous_scale='RdYlGn'
            )
            ranking_fig.update_layout(height=max(400, len(recommended_frameworks) * 40))
            st.plotly_chart(ranking_fig, use_container_width=True)
    
    # Detailed recommendations table
    if selected_industry and not recommended_frameworks.empty:
        st.markdown("---")
        st.subheader("📋 Detailed Recommendations")
        
        # Enhanced dataframe with recommendations
        display_df = recommended_frameworks.head(max_frameworks).copy()
        
        st.dataframe(
            display_df[['name', 'category', 'core_function', 'complexity', 'time_to_implement', 'cost', 'effectiveness', 'score']],
            column_config={
                'name': 'Framework Name',
                'category': 'Category',
                'core_function': 'Core Function',
                'complexity': st.column_config.ProgressColumn('Complexity', min_value=1, max_value=5),
                'time_to_implement': st.column_config.ProgressColumn('Implementation Time', min_value=1, max_value=5),
                'cost': st.column_config.ProgressColumn('Cost', min_value=1, max_value=5),
                'effectiveness': st.column_config.ProgressColumn('Effectiveness', min_value=1, max_value=5),
                'score': st.column_config.NumberColumn('Score', format="%.1f")
            },
            hide_index=True,
            use_container_width=True
        )
        
        # Industry insights
        st.markdown("#### 💡 Industry Insights")
        
        avg_complexity = display_df['complexity'].mean()
        avg_cost = display_df['cost'].mean()
        avg_time = display_df['time_to_implement'].mean()
        
        insight_col1, insight_col2, insight_col3 = st.columns(3)
        
        with insight_col1:
            complexity_level = "High" if avg_complexity >= 4 else "Medium" if avg_complexity >= 3 else "Low"
            st.info(f"**Complexity Level:** {complexity_level}\n\nFrameworks in {selected_industry} typically have {complexity_level.lower()} complexity requirements.")
        
        with insight_col2:
            cost_level = "High" if avg_cost >= 4 else "Medium" if avg_cost >= 3 else "Low"
            st.info(f"**Cost Profile:** {cost_level}\n\nImplementation costs in {selected_industry} are typically {cost_level.lower()}.")
        
        with insight_col3:
            time_level = "Long" if avg_time >= 4 else "Medium" if avg_time >= 3 else "Short"
            st.info(f"**Implementation Time:** {time_level}\n\nFrameworks in {selected_industry} typically require {time_level.lower()} implementation timelines.")

def show_smart_recommendations(frameworks_df):
    """Show smart personalized recommendations"""
    
    st.subheader("🧠 Smart Personalized Recommendations")
    st.markdown("Answer a few questions to get personalized framework recommendations tailored to your specific situation.")
    
    # User profile form
    with st.form("user_profile_form"):
        st.markdown("#### 👤 Company Profile")
        
        col1, col2 = st.columns(2)
        
        with col1:
            industry = st.selectbox(
                "Industry:",
                [""] + list(get_industry_framework_mapping().keys()),
                help="Select your industry for specialized recommendations"
            )
            
            company_size = st.selectbox(
                "Company Size:",
                ["Small (1-50 employees)", "Medium (51-500 employees)", "Large (500+ employees)"],
                index=1,
                help="Company size affects resource availability and implementation capacity"
            )
            
            experience_level = st.selectbox(
                "Team Experience Level:",
                ["Beginner", "Intermediate", "Expert"],
                index=1,
                help="Experience level with business frameworks and methodologies"
            )
        
        with col2:
            budget = st.selectbox(
                "Budget Level:",
                ["Low", "Medium", "High"],
                index=1,
                help="Available budget for framework implementation"
            )
            
            timeline = st.selectbox(
                "Timeline Preference:",
                ["Urgent (need results quickly)", "Medium (standard timeline)", "Flexible (can take time)"],
                index=1,
                help="How quickly you need to see results"
            )
            
            primary_goal = st.selectbox(
                "Primary Goal:",
                ["Strategic Planning", "Process Improvement", "Innovation", "Marketing", 
                 "Project Management", "Change Management", "Risk Management", 
                 "Financial Analysis", "General Improvement"],
                index=8,
                help="What you're primarily trying to achieve"
            )
        
        submitted = st.form_submit_button("🎯 Get Personalized Recommendations", type="primary")
    
    if submitted:
        # Process user inputs
        user_inputs = {
            'industry': industry if industry else None,
            'company_size': company_size.split()[0],  # Extract size category
            'budget': budget,
            'timeline': timeline.split()[0],  # Extract timeline category  
            'experience_level': experience_level,
            'primary_goal': primary_goal
        }
        
        # Get smart recommendations
        recommendations, explanations = get_smart_recommendations(user_inputs)
        
        if recommendations.empty:
            st.warning("No frameworks match your criteria. Please adjust your requirements.")
            return
        
        # Display recommendations
        st.markdown("---")
        st.subheader("🎯 Your Personalized Recommendations")
        
        # Show explanation
        if explanations:
            st.markdown("#### 📝 Why These Recommendations?")
            for explanation in explanations:
                st.markdown(f"• {explanation}")
        
        # Top 3 recommendations highlight
        st.markdown("#### ⭐ Top 3 Recommendations")
        
        top_3 = recommendations.head(3)
        
        for idx, (_, framework) in enumerate(top_3.iterrows(), 1):
            with st.expander(f"#{idx} {framework['name']} (Score: {framework['final_score']:.1f})", expanded=idx==1):
                col_a, col_b = st.columns([2, 1])
                
                with col_a:
                    st.write(f"**Category:** {framework['category']}")
                    st.write(f"**Core Function:** {framework['core_function']}")
                    st.write(f"**Typical Uses:** {framework['typical_uses']}")
                
                with col_b:
                    # Mini radar chart for this framework
                    characteristics = {
                        'Complexity': framework['complexity'],
                        'Time': framework['time_to_implement'],
                        'Cost': framework['cost'],
                        'Effectiveness': framework['effectiveness']
                    }
                    
                    fig = go.Figure()
                    fig.add_trace(go.Scatterpolar(
                        r=list(characteristics.values()),
                        theta=list(characteristics.keys()),
                        fill='toself',
                        name=framework['name']
                    ))
                    fig.update_layout(
                        polar=dict(radialaxis=dict(visible=True, range=[0, 5])),
                        showlegend=False,
                        height=250,
                        margin=dict(l=0, r=0, t=0, b=0)
                    )
                    st.plotly_chart(fig, use_container_width=True)
        
        # Full recommendations table
        st.markdown("#### 📊 Complete Recommendations List")
        
        st.dataframe(
            recommendations[['name', 'category', 'complexity', 'time_to_implement', 'cost', 'effectiveness', 'final_score']],
            column_config={
                'name': 'Framework Name',
                'category': 'Category',
                'complexity': st.column_config.ProgressColumn('Complexity', min_value=1, max_value=5),
                'time_to_implement': st.column_config.ProgressColumn('Implementation Time', min_value=1, max_value=5),
                'cost': st.column_config.ProgressColumn('Cost', min_value=1, max_value=5),
                'effectiveness': st.column_config.ProgressColumn('Effectiveness', min_value=1, max_value=5),
                'final_score': st.column_config.NumberColumn('Personalization Score', format="%.1f")
            },
            hide_index=True,
            use_container_width=True
        )
        
        # Implementation planning
        st.markdown("---")
        st.subheader("📅 Implementation Planning")
        
        # Select frameworks for roadmap
        selected_for_roadmap = st.multiselect(
            "Select frameworks to include in implementation roadmap:",
            recommendations['name'].tolist(),
            default=recommendations.head(5)['name'].tolist(),
            help="Choose which frameworks you want to implement"
        )
        
        if selected_for_roadmap:
            roadmap, roadmap_error = get_implementation_roadmap(selected_for_roadmap)
            
            if roadmap_error:
                st.error(roadmap_error)
            else:
                # Display roadmap
                for phase in roadmap:
                    with st.expander(f"📋 {phase['phase']} (Months {phase['start_month']}-{phase['start_month'] + phase['duration']})", expanded=True):
                        st.write(f"**Duration:** {phase['duration']} months")
                        st.write(f"**Description:** {phase['description']}")
                        st.write(f"**Frameworks:** {', '.join(phase['frameworks'])}")
                        
                        col_road1, col_road2 = st.columns(2)
                        with col_road1:
                            st.metric("Total Cost Level", phase['total_cost'])
                        with col_road2:
                            st.metric("Expected Effectiveness", f"{phase['expected_effectiveness']}/5")

def show_framework_alternatives(frameworks_df):
    """Show framework alternatives"""
    
    st.subheader("🔄 Framework Alternatives")
    st.markdown("Find alternative frameworks that serve similar purposes or complement existing choices.")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("#### 🎯 Find Alternatives")
        
        # Framework selection for alternatives
        framework_for_alternatives = st.selectbox(
            "Select a framework to find alternatives:",
            frameworks_df['name'].tolist(),
            help="Choose a framework to find similar alternatives"
        )
        
        num_alternatives = st.slider(
            "Number of alternatives:",
            min_value=3,
            max_value=10,
            value=5,
            help="How many alternatives to show"
        )
        
        # Find alternatives
        if framework_for_alternatives:
            alternatives_df, alt_error = get_framework_alternatives(framework_for_alternatives, num_alternatives)
            
            if alt_error:
                st.error(alt_error)
            else:
                st.markdown(f"#### 🔍 Found {len(alternatives_df)} alternatives")
                
                # Show similarity scores
                for _, alt in alternatives_df.iterrows():
                    similarity_pct = alt['similarity_score'] * 100
                    st.write(f"**{alt['name']}** - {similarity_pct:.1f}% similar")
    
    with col2:
        if 'alternatives_df' in locals() and not alternatives_df.empty:
            st.markdown("#### 📊 Alternatives Comparison")
            
            # Create comparison visualization
            comparison_data = frameworks_df[frameworks_df['name'].isin([framework_for_alternatives] + alternatives_df['name'].tolist())]
            
            # Radar chart comparison
            fig = go.Figure()
            
            colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#FF9FF3']
            
            for i, (_, framework) in enumerate(comparison_data.iterrows()):
                values = [framework['complexity'], framework['time_to_implement'], framework['cost'], framework['effectiveness']]
                
                fig.add_trace(go.Scatterpolar(
                    r=values,
                    theta=['Complexity', 'Time', 'Cost', 'Effectiveness'],
                    fill='toself',
                    name=framework['name'],
                    line_color=colors[i % len(colors)]
                ))
            
            fig.update_layout(
                polar=dict(radialaxis=dict(visible=True, range=[0, 5])),
                showlegend=True,
                title="Framework Alternatives Comparison",
                height=500
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Detailed alternatives table
            st.markdown("#### 📋 Detailed Alternatives")
            
            st.dataframe(
                alternatives_df[['name', 'category', 'similarity_score', 'complexity', 'time_to_implement', 'cost', 'effectiveness']],
                column_config={
                    'name': 'Framework Name',
                    'category': 'Category',
                    'similarity_score': st.column_config.ProgressColumn('Similarity', min_value=0, max_value=1),
                    'complexity': st.column_config.ProgressColumn('Complexity', min_value=1, max_value=5),
                    'time_to_implement': st.column_config.ProgressColumn('Implementation Time', min_value=1, max_value=5),
                    'cost': st.column_config.ProgressColumn('Cost', min_value=1, max_value=5),
                    'effectiveness': st.column_config.ProgressColumn('Effectiveness', min_value=1, max_value=5)
                },
                hide_index=True,
                use_container_width=True
            )
    
    # Complementary frameworks section
    st.markdown("---")
    st.subheader("🤝 Complementary Frameworks")
    st.markdown("Find frameworks that work well together with your selected frameworks.")
    
    # Multi-select for frameworks to find complements
    selected_frameworks = st.multiselect(
        "Select frameworks to find complements for:",
        frameworks_df['name'].tolist(),
        help="Choose frameworks you're already using or planning to use"
    )
    
    if selected_frameworks:
        complementary_df, comp_error = get_complementary_frameworks(selected_frameworks, n_recommendations=8)
        
        if comp_error:
            st.error(comp_error)
        elif complementary_df.empty:
            st.info("No complementary frameworks found for your selection.")
        else:
            # Display complementary frameworks
            col3, col4 = st.columns([1, 1])
            
            with col3:
                st.markdown("#### 🎯 Top Complementary Frameworks")
                
                for _, comp in complementary_df.head(5).iterrows():
                    diversity_icon = "🆕" if comp['category_diversity'] else "🔄"
                    st.write(f"{diversity_icon} **{comp['name']}** (Score: {comp['complementary_score']:.2f})")
                    st.caption(f"Category: {comp['category']}")
            
            with col4:
                # Complementary score visualization
                comp_fig = px.bar(
                    complementary_df.head(8),
                    x='complementary_score',
                    y='name',
                    orientation='h',
                    color='category_diversity',
                    title="Complementary Framework Scores",
                    labels={'complementary_score': 'Complementary Score', 'name': 'Framework'},
                    color_discrete_map={True: '#4ECDC4', False: '#FF9FF3'}
                )
                comp_fig.update_layout(height=400)
                st.plotly_chart(comp_fig, use_container_width=True)
    
    # Export functionality
    st.markdown("---")
    st.subheader("📤 Export Recommendations")
    
    if st.button("📋 Generate Recommendations Report", type="primary"):
        # Compile all recommendations data
        report_sections = []
        
        if 'recommended_frameworks' in locals() and not recommended_frameworks.empty:
            report_sections.append(("Industry_Recommendations", recommended_frameworks))
        
        if 'recommendations' in locals() and not recommendations.empty:
            report_sections.append(("Personalized_Recommendations", recommendations))
        
        if 'alternatives_df' in locals() and not alternatives_df.empty:
            report_sections.append(("Framework_Alternatives", alternatives_df))
        
        if 'complementary_df' in locals() and not complementary_df.empty:
            report_sections.append(("Complementary_Frameworks", complementary_df))
        
        if report_sections:
            # Create combined report
            with pd.ExcelWriter('framework_recommendations_report.xlsx', engine='openpyxl') as writer:
                for section_name, section_df in report_sections:
                    section_df.to_excel(writer, sheet_name=section_name, index=False)
            
            st.success("✅ Comprehensive recommendations report generated!")
            
            # Provide summary
            st.markdown("**Report includes:**")
            for section_name, section_df in report_sections:
                st.write(f"• {section_name.replace('_', ' ')}: {len(section_df)} frameworks")
        else:
            st.info("Generate some recommendations first to create a report.")

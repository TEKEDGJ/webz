import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from data.frameworks_data import get_all_frameworks, get_framework_categories
from utils.visualization import create_comparative_radar, create_implementation_timeline
from utils.analysis import calculate_framework_score

def show_page():
    """Display the Comparative Analysis page"""
    
    st.title("⚖️ Comparative Analysis")
    st.markdown("Compare multiple frameworks side by side to make informed decisions.")
    
    # Load data
    frameworks_df = get_all_frameworks()
    categories = get_framework_categories()
    
    # Framework selection section
    st.subheader("🎯 Select Frameworks to Compare")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Multi-select for frameworks
        selected_frameworks = st.multiselect(
            "Choose frameworks to compare (2-6 recommended):",
            frameworks_df['name'].tolist(),
            default=['SWOT Analysis', 'Porter\'s Five Forces', 'Business Model Canvas'],
            help="Select multiple frameworks to compare their characteristics"
        )
    
    with col2:
        # Category filter for easier selection
        category_filter = st.selectbox(
            "Filter by category:",
            ['All Categories'] + categories,
            help="Filter frameworks by category to make selection easier"
        )
        
        if category_filter != 'All Categories':
            category_frameworks = frameworks_df[frameworks_df['category'] == category_filter]['name'].tolist()
            if st.button("Add All from Category"):
                selected_frameworks.extend([fw for fw in category_frameworks if fw not in selected_frameworks])
                st.rerun()
    
    if not selected_frameworks:
        st.warning("Please select at least one framework to begin comparison.")
        return
    
    # Get selected framework data
    comparison_df = frameworks_df[frameworks_df['name'].isin(selected_frameworks)].copy()
    
    # Add calculated scores
    comparison_df['overall_score'] = comparison_df.apply(
        lambda row: calculate_framework_score(row), axis=1
    )
    
    # Summary metrics
    st.markdown("---")
    st.subheader("📊 Quick Comparison")
    
    col3, col4, col5, col6 = st.columns(4)
    
    with col3:
        avg_complexity = comparison_df['complexity'].mean()
        st.metric(
            "Avg Complexity",
            f"{avg_complexity:.1f}/5",
            help="Average complexity level of selected frameworks"
        )
    
    with col4:
        avg_time = comparison_df['time_to_implement'].mean()
        st.metric(
            "Avg Implementation Time",
            f"{avg_time:.1f}/5",
            help="Average time to implement selected frameworks"
        )
    
    with col5:
        avg_cost = comparison_df['cost'].mean()
        st.metric(
            "Avg Cost",
            f"{avg_cost:.1f}/5",
            help="Average implementation cost of selected frameworks"
        )
    
    with col6:
        avg_effectiveness = comparison_df['effectiveness'].mean()
        st.metric(
            "Avg Effectiveness",
            f"{avg_effectiveness:.1f}/5",
            help="Average effectiveness rating of selected frameworks"
        )
    
    # Main comparison visualizations
    st.markdown("---")
    st.subheader("📈 Detailed Comparison Charts")
    
    # Tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["Radar Comparison", "Characteristics Matrix", "Score Analysis", "Implementation Planning"])
    
    with tab1:
        st.markdown("#### Multi-Framework Radar Chart")
        
        # Comparative radar chart
        radar_fig = create_comparative_radar(frameworks_df, selected_frameworks)
        st.plotly_chart(radar_fig, use_container_width=True)
        
        # Insights
        st.markdown("##### 🔍 Key Insights:")
        
        # Find best in each category
        best_effectiveness = comparison_df.loc[comparison_df['effectiveness'].idxmax(), 'name']
        lowest_cost = comparison_df.loc[comparison_df['cost'].idxmin(), 'name']
        fastest_implementation = comparison_df.loc[comparison_df['time_to_implement'].idxmin(), 'name']
        lowest_complexity = comparison_df.loc[comparison_df['complexity'].idxmin(), 'name']
        
        col7, col8 = st.columns(2)
        
        with col7:
            st.write(f"🏆 **Most Effective:** {best_effectiveness}")
            st.write(f"💰 **Lowest Cost:** {lowest_cost}")
        
        with col8:
            st.write(f"⚡ **Fastest Implementation:** {fastest_implementation}")
            st.write(f"🎯 **Lowest Complexity:** {lowest_complexity}")
    
    with tab2:
        st.markdown("#### Characteristics Matrix")
        
        # Create heatmap of characteristics
        characteristics_matrix = comparison_df.set_index('name')[['complexity', 'time_to_implement', 'cost', 'effectiveness']]
        
        fig_heatmap = px.imshow(
            characteristics_matrix.T,
            labels=dict(x="Framework", y="Characteristic", color="Rating"),
            x=characteristics_matrix.index,
            y=['Complexity', 'Time to Implement', 'Cost', 'Effectiveness'],
            color_continuous_scale='RdYlGn',
            title="Framework Characteristics Heatmap"
        )
        
        fig_heatmap.update_layout(height=400)
        st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Detailed comparison table
        st.markdown("#### Detailed Comparison Table")
        
        display_df = comparison_df[['name', 'category', 'complexity', 'time_to_implement', 'cost', 'effectiveness', 'overall_score']]
        
        st.dataframe(
            display_df,
            column_config={
                'name': 'Framework Name',
                'category': 'Category',
                'complexity': st.column_config.ProgressColumn('Complexity', min_value=1, max_value=5),
                'time_to_implement': st.column_config.ProgressColumn('Time to Implement', min_value=1, max_value=5),
                'cost': st.column_config.ProgressColumn('Cost', min_value=1, max_value=5),
                'effectiveness': st.column_config.ProgressColumn('Effectiveness', min_value=1, max_value=5),
                'overall_score': st.column_config.NumberColumn('Overall Score', format="%.1f")
            },
            hide_index=True,
            use_container_width=True
        )
    
    with tab3:
        st.markdown("#### Score Analysis")
        
        # Overall score comparison
        score_fig = px.bar(
            comparison_df.sort_values('overall_score', ascending=True),
            x='overall_score',
            y='name',
            orientation='h',
            title="Overall Framework Scores",
            labels={'overall_score': 'Overall Score', 'name': 'Framework'},
            color='overall_score',
            color_continuous_scale='RdYlGn'
        )
        score_fig.update_layout(height=max(400, len(selected_frameworks) * 50))
        st.plotly_chart(score_fig, use_container_width=True)
        
        # Score components breakdown
        st.markdown("#### Score Components Breakdown")
        
        # Create stacked bar chart showing score components
        score_components = []
        
        for _, framework in comparison_df.iterrows():
            # Calculate individual component contributions to score
            complexity_score = (5 - framework['complexity']) * 20  # Inverse for complexity
            time_score = (5 - framework['time_to_implement']) * 20  # Inverse for time
            cost_score = (5 - framework['cost']) * 30  # Inverse for cost
            effectiveness_score = framework['effectiveness'] * 20
            
            score_components.append({
                'Framework': framework['name'],
                'Complexity': complexity_score,
                'Time': time_score,
                'Cost': cost_score,
                'Effectiveness': effectiveness_score
            })
        
        components_df = pd.DataFrame(score_components)
        
        fig_components = px.bar(
            components_df.melt(id_vars=['Framework'], var_name='Component', value_name='Score'),
            x='Framework',
            y='Score',
            color='Component',
            title="Score Components by Framework",
            labels={'Score': 'Component Score'}
        )
        fig_components.update_xaxes(tickangle=45)
        st.plotly_chart(fig_components, use_container_width=True)
    
    with tab4:
        st.markdown("#### Implementation Planning")
        
        # Implementation timeline
        timeline_fig = create_implementation_timeline(frameworks_df, selected_frameworks)
        st.plotly_chart(timeline_fig, use_container_width=True)
        
        # Resource planning
        st.markdown("#### Resource Requirements")
        
        col9, col10 = st.columns(2)
        
        with col9:
            # Total implementation time
            total_time_parallel = comparison_df['time_to_implement'].max()
            total_time_sequential = comparison_df['time_to_implement'].sum()
            
            st.metric(
                "Parallel Implementation",
                f"{total_time_parallel} months",
                help="Time needed if implementing all frameworks simultaneously"
            )
            
            st.metric(
                "Sequential Implementation",
                f"{total_time_sequential} months",
                help="Time needed if implementing frameworks one after another"
            )
        
        with col10:
            # Cost analysis
            total_cost = comparison_df['cost'].sum()
            avg_cost = comparison_df['cost'].mean()
            
            st.metric(
                "Total Cost Level",
                f"{total_cost:.0f}/25",
                help="Sum of all framework cost levels"
            )
            
            st.metric(
                "Average Cost Level",
                f"{avg_cost:.1f}/5",
                help="Average cost level across selected frameworks"
            )
        
        # Implementation recommendations
        st.markdown("#### 🎯 Implementation Recommendations")
        
        # Sort frameworks for implementation order
        implementation_order = comparison_df.sort_values(['cost', 'complexity', 'time_to_implement']).copy()
        
        st.markdown("**Suggested Implementation Order:**")
        for i, (_, framework) in enumerate(implementation_order.iterrows(), 1):
            effectiveness_stars = "⭐" * int(framework['effectiveness'])
            st.write(f"{i}. **{framework['name']}** {effectiveness_stars}")
            st.write(f"   *Rationale: {get_implementation_rationale(framework)}*")
    
    # Export functionality
    st.markdown("---")
    st.subheader("📤 Export Comparison")
    
    col11, col12 = st.columns(2)
    
    with col11:
        if st.button("📊 Generate Comparison Report", type="primary"):
            # Create comprehensive comparison report
            report_data = []
            
            for _, framework in comparison_df.iterrows():
                report_data.append({
                    'Framework_Name': framework['name'],
                    'Category': framework['category'],
                    'Core_Function': framework['core_function'],
                    'Typical_Uses': framework['typical_uses'],
                    'Complexity': framework['complexity'],
                    'Time_to_Implement': framework['time_to_implement'],
                    'Cost': framework['cost'],
                    'Effectiveness': framework['effectiveness'],
                    'Overall_Score': framework['overall_score']
                })
            
            report_df = pd.DataFrame(report_data)
            
            # Download button
            csv = report_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Comparison Report (CSV)",
                data=csv,
                file_name=f"framework_comparison_{len(selected_frameworks)}_frameworks.csv",
                mime="text/csv"
            )
    
    with col12:
        if st.button("📋 Create Implementation Plan"):
            # Create implementation plan
            plan_data = []
            
            for i, (_, framework) in enumerate(implementation_order.iterrows(), 1):
                plan_data.append({
                    'Order': i,
                    'Framework': framework['name'],
                    'Category': framework['category'],
                    'Estimated_Duration_Months': framework['time_to_implement'],
                    'Cost_Level': framework['cost'],
                    'Complexity_Level': framework['complexity'],
                    'Expected_Effectiveness': framework['effectiveness'],
                    'Implementation_Notes': get_implementation_rationale(framework)
                })
            
            plan_df = pd.DataFrame(plan_data)
            
            # Download button
            csv = plan_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Implementation Plan (CSV)",
                data=csv,
                file_name=f"implementation_plan_{len(selected_frameworks)}_frameworks.csv",
                mime="text/csv"
            )

def get_implementation_rationale(framework):
    """Generate implementation rationale for a framework"""
    
    rationale_parts = []
    
    if framework['cost'] <= 2:
        rationale_parts.append("low cost")
    if framework['complexity'] <= 2:
        rationale_parts.append("low complexity")
    if framework['time_to_implement'] <= 2:
        rationale_parts.append("quick implementation")
    if framework['effectiveness'] >= 4:
        rationale_parts.append("high effectiveness")
    
    if not rationale_parts:
        rationale_parts.append("balanced characteristics")
    
    return f"Recommended due to {', '.join(rationale_parts)}"

import pandas as pd
import numpy as np

def get_all_frameworks():
    """Return a comprehensive dataframe of all 100 business frameworks"""
    
    frameworks_data = [
        # Strategic Planning Frameworks
        {"id": 1, "name": "SWOT Analysis", "category": "Strategic Planning Frameworks", 
         "core_function": "Identify internal strengths & weaknesses, external opportunities & threats",
         "typical_uses": "Strategic decision-making; prioritizing initiatives",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 4},
        
        {"id": 2, "name": "TOWS Matrix", "category": "Strategic Planning Frameworks",
         "core_function": "Link SWOT factors to strategic options",
         "typical_uses": "Generate SO, WO, ST, WT strategies",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 3, "name": "PESTEL Analysis", "category": "Strategic Planning Frameworks",
         "core_function": "Scan macro-environmental factors",
         "typical_uses": "Assess external risks & drivers; inform strategic planning",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 4, "name": "Porter's Five Forces", "category": "Strategic Planning Frameworks",
         "core_function": "Analyze industry competitive intensity",
         "typical_uses": "Evaluate attractiveness & profitability of an industry",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 5},
        
        {"id": 5, "name": "Balanced Scorecard", "category": "Strategic Planning Frameworks",
         "core_function": "Translate strategy into performance metrics",
         "typical_uses": "Align objectives, measure balanced financial/non-financial KPIs",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 6, "name": "BCG Growth-Share Matrix", "category": "Strategic Planning Frameworks",
         "core_function": "Classify business units by market growth & share",
         "typical_uses": "Resource allocation; portfolio prioritization",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 7, "name": "Ansoff Matrix", "category": "Strategic Planning Frameworks",
         "core_function": "Evaluate product/market growth strategies",
         "typical_uses": "Decide on market penetration, product development, market expansion, diversification",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 8, "name": "VRIO Framework", "category": "Strategic Planning Frameworks",
         "core_function": "Assess internal resources & capabilities",
         "typical_uses": "Identify competitive advantages based on Value, Rarity, Imitability, Organization",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 9, "name": "McKinsey 7S Framework", "category": "Strategic Planning Frameworks",
         "core_function": "Align seven internal elements (strategy, structure, systems, shared values, skills, style, staff)",
         "typical_uses": "Organizational change & alignment",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 10, "name": "Scenario Planning", "category": "Strategic Planning Frameworks",
         "core_function": "Develop divergent future scenarios",
         "typical_uses": "Test strategic robustness; stress-test plans",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        # Marketing Frameworks
        {"id": 11, "name": "Marketing Mix (4Ps)", "category": "Marketing Frameworks",
         "core_function": "Structure product, price, place, promotion decisions",
         "typical_uses": "Develop go-to-market strategy",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 12, "name": "Extended Marketing Mix (7Ps)", "category": "Marketing Frameworks",
         "core_function": "Include People, Process, Physical evidence",
         "typical_uses": "Service marketing planning",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 13, "name": "4Cs Model (Lauterborn)", "category": "Marketing Frameworks",
         "core_function": "Customer, Cost, Convenience, Communication",
         "typical_uses": "Customer-centric marketing approach",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 14, "name": "AIDA Model", "category": "Marketing Frameworks",
         "core_function": "Attention, Interest, Desire, Action",
         "typical_uses": "Craft effective advertising copy & campaigns",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        {"id": 15, "name": "Customer Journey Mapping", "category": "Marketing Frameworks",
         "core_function": "Visualize customer interactions & touchpoints",
         "typical_uses": "Enhance CX; identify pain points",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 5},
        
        {"id": 16, "name": "Buyer Personas", "category": "Marketing Frameworks",
         "core_function": "Create archetypal customer profiles",
         "typical_uses": "Tailor messaging, product features to target segments",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 17, "name": "RACE Framework", "category": "Marketing Frameworks",
         "core_function": "Reach, Act, Convert, Engage",
         "typical_uses": "Digital marketing funnel optimization",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 18, "name": "SOSTAC Planning", "category": "Marketing Frameworks",
         "core_function": "Situation, Objectives, Strategy, Tactics, Action, Control",
         "typical_uses": "Comprehensive marketing plan framework",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 5},
        
        {"id": 19, "name": "DAGMAR", "category": "Marketing Frameworks",
         "core_function": "Define Advertising Goals for Measured Advertising Results",
         "typical_uses": "Set measurable objectives for promotional activities",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 20, "name": "7Cs Compass Model", "category": "Marketing Frameworks",
         "core_function": "Commodity, Cost, Channel, Communication, Customer, and two others",
         "typical_uses": "Strategic marketing alignment",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Quality & Operations Excellence
        {"id": 21, "name": "Lean Management", "category": "Quality & Operations Excellence",
         "core_function": "Eliminate waste & improve flow",
         "typical_uses": "Streamline processes; reduce lead time",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 22, "name": "Six Sigma", "category": "Quality & Operations Excellence",
         "core_function": "Reduce process variability & defects",
         "typical_uses": "Improve quality; achieve near-perfect outputs",
         "complexity": 5, "time_to_implement": 5, "cost": 4, "effectiveness": 5},
        
        {"id": 23, "name": "Lean Six Sigma", "category": "Quality & Operations Excellence",
         "core_function": "Combine Lean & Six Sigma tools",
         "typical_uses": "Accelerate value creation; minimize waste & variation",
         "complexity": 5, "time_to_implement": 5, "cost": 4, "effectiveness": 5},
        
        {"id": 24, "name": "PDCA Cycle", "category": "Quality & Operations Excellence",
         "core_function": "Plan–Do–Check–Act iterative improvement",
         "typical_uses": "Continuous quality & process improvement",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 25, "name": "DMAIC", "category": "Quality & Operations Excellence",
         "core_function": "Define–Measure–Analyze–Improve–Control",
         "typical_uses": "Structured Six Sigma problem-solving",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 26, "name": "Kaizen", "category": "Quality & Operations Excellence",
         "core_function": "Small, incremental improvements",
         "typical_uses": "Foster culture of ongoing enhancement",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 27, "name": "5S Methodology", "category": "Quality & Operations Excellence",
         "core_function": "Sort, Set in order, Shine, Standardize, Sustain",
         "typical_uses": "Workplace organization & efficiency",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 3},
        
        {"id": 28, "name": "Total Quality Management (TQM)", "category": "Quality & Operations Excellence",
         "core_function": "Holistic quality culture & practices",
         "typical_uses": "Enterprise-wide quality enhancement",
         "complexity": 5, "time_to_implement": 5, "cost": 4, "effectiveness": 5},
        
        {"id": 29, "name": "Quality Function Deployment", "category": "Quality & Operations Excellence",
         "core_function": "Translate customer requirements into technical features",
         "typical_uses": "Align product design with voice of customer",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 30, "name": "ISO 9001 Quality Management", "category": "Quality & Operations Excellence",
         "core_function": "Standardize QMS requirements",
         "typical_uses": "Certification; consistent product/service quality",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        # Innovation & Design
        {"id": 31, "name": "Design Thinking", "category": "Innovation & Design",
         "core_function": "Human-centric, iterative ideation & prototyping",
         "typical_uses": "Solve complex customer-facing problems; innovate products/services",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 5},
        
        {"id": 32, "name": "Business Model Canvas", "category": "Innovation & Design",
         "core_function": "Visualize & test business model building blocks",
         "typical_uses": "Develop, pivot, or validate business models",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 5},
        
        {"id": 33, "name": "Lean Canvas", "category": "Innovation & Design",
         "core_function": "Adapt Business Model Canvas for startups",
         "typical_uses": "Rapid hypothesis testing; lean startup methodology",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 34, "name": "Value Proposition Canvas", "category": "Innovation & Design",
         "core_function": "Deep dive on customer segments & value propositions",
         "typical_uses": "Refine offering to meet customer needs",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 35, "name": "TRIZ", "category": "Innovation & Design",
         "core_function": "Systematic inventive problem solving",
         "typical_uses": "Generate breakthrough solutions via patterns",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 36, "name": "Stage-Gate Process", "category": "Innovation & Design",
         "core_function": "Gate-based NPD methodology",
         "typical_uses": "Manage product development phases & go/no-go decisions",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 37, "name": "Innovation Funnel", "category": "Innovation & Design",
         "core_function": "Funnel approach to idea screening & development",
         "typical_uses": "Prioritize, develop, and scale ideas",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 38, "name": "Open Innovation Model", "category": "Innovation & Design",
         "core_function": "Leverage external ideas & collaborations",
         "typical_uses": "Accelerate R&D; co-create with partners",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 39, "name": "Blue Ocean Strategy", "category": "Innovation & Design",
         "core_function": "Create uncontested market space",
         "typical_uses": "Identify differentiation opportunities",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 40, "name": "Human-Centered Design", "category": "Innovation & Design",
         "core_function": "Integrate user needs at each design stage",
         "typical_uses": "Enhance usability & adoption",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Decision-Making & Analysis
        {"id": 41, "name": "Decision Tree Analysis", "category": "Decision-Making & Analysis",
         "core_function": "Graphical decision & probability modeling",
         "typical_uses": "Evaluate complex decisions under uncertainty",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 42, "name": "Cost-Benefit Analysis (CBA)", "category": "Decision-Making & Analysis",
         "core_function": "Quantify benefits vs costs",
         "typical_uses": "Assess project or policy viability",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 43, "name": "Pugh Decision Matrix", "category": "Decision-Making & Analysis",
         "core_function": "Compare options against criteria",
         "typical_uses": "Prioritize alternatives",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        {"id": 44, "name": "Multi-Criteria Decision Analysis (MCDA)", "category": "Decision-Making & Analysis",
         "core_function": "Rank options via weighted criteria",
         "typical_uses": "Balanced decision-making across diverse factors",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 45, "name": "Net Present Value (NPV)", "category": "Decision-Making & Analysis",
         "core_function": "Discounted cash-flow evaluation",
         "typical_uses": "Investment appraisal",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 46, "name": "Internal Rate of Return (IRR)", "category": "Decision-Making & Analysis",
         "core_function": "Rate that zeroes NPV",
         "typical_uses": "Compare project yields",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 47, "name": "Break-Even Analysis", "category": "Decision-Making & Analysis",
         "core_function": "Determine sales volume to cover costs",
         "typical_uses": "Pricing & volume planning",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        {"id": 48, "name": "RACI Matrix", "category": "Decision-Making & Analysis",
         "core_function": "Clarify roles: Responsible, Accountable, Consulted, Informed",
         "typical_uses": "Project role clarity; governance",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 4},
        
        {"id": 49, "name": "MOST Analysis", "category": "Decision-Making & Analysis",
         "core_function": "Mission, Objectives, Strategies, Tactics",
         "typical_uses": "Align initiatives with mission",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 50, "name": "MoSCoW Prioritization", "category": "Decision-Making & Analysis",
         "core_function": "Must, Should, Could, Won't",
         "typical_uses": "Feature or requirement prioritization",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        # Project & Portfolio Management
        {"id": 51, "name": "Critical Path Method (CPM)", "category": "Project & Portfolio Management",
         "core_function": "Identify longest project path & schedule",
         "typical_uses": "Plan & control project timelines",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 52, "name": "PERT", "category": "Project & Portfolio Management",
         "core_function": "Incorporate variability in task durations",
         "typical_uses": "Schedule high-uncertainty projects",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 53, "name": "Earned Value Management (EVM)", "category": "Project & Portfolio Management",
         "core_function": "Integrate scope, schedule & cost performance",
         "typical_uses": "Monitor project health",
         "complexity": 4, "time_to_implement": 3, "cost": 3, "effectiveness": 5},
        
        {"id": 54, "name": "Scrum", "category": "Project & Portfolio Management",
         "core_function": "Agile iterative development framework",
         "typical_uses": "Manage software or product sprints",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 55, "name": "Kanban", "category": "Project & Portfolio Management",
         "core_function": "Visual workflow management",
         "typical_uses": "Optimize flow; limit WIP",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 4},
        
        {"id": 56, "name": "Waterfall", "category": "Project & Portfolio Management",
         "core_function": "Sequential project lifecycle",
         "typical_uses": "Traditional engineering or construction projects",
         "complexity": 2, "time_to_implement": 2, "cost": 2, "effectiveness": 3},
        
        {"id": 57, "name": "PRINCE2", "category": "Project & Portfolio Management",
         "core_function": "Process-based project governance",
         "typical_uses": "Standardized project structure",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 58, "name": "PMBOK Guide", "category": "Project & Portfolio Management",
         "core_function": "Standardized project management body of knowledge",
         "typical_uses": "Common PMI practices",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 59, "name": "Critical Chain Project Management (CCPM)", "category": "Project & Portfolio Management",
         "core_function": "Buffer-focused scheduling",
         "typical_uses": "Improve on-time delivery under resource constraints",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 60, "name": "Agile Project Management", "category": "Project & Portfolio Management",
         "core_function": "Adaptive project management approach",
         "typical_uses": "Manage projects with changing requirements",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Change & Organizational Management
        {"id": 61, "name": "Kotter's 8-Step Model", "category": "Change & Organizational Management",
         "core_function": "Eight phases for leading change",
         "typical_uses": "Drive successful transformation initiatives",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 62, "name": "ADKAR Model", "category": "Change & Organizational Management",
         "core_function": "Awareness, Desire, Knowledge, Ability, Reinforcement",
         "typical_uses": "Individual change management",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 63, "name": "Lewin's Change Model", "category": "Change & Organizational Management",
         "core_function": "Unfreeze, Change, Refreeze",
         "typical_uses": "High-level change process",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 3},
        
        {"id": 64, "name": "Force Field Analysis", "category": "Change & Organizational Management",
         "core_function": "Identify driving & restraining forces",
         "typical_uses": "Balance change enablers vs barriers",
         "complexity": 3, "time_to_implement": 2, "cost": 1, "effectiveness": 4},
        
        {"id": 65, "name": "Nadler-Tushman Congruence", "category": "Change & Organizational Management",
         "core_function": "Align people, structure, tasks, culture",
         "typical_uses": "Diagnose organizational misalignment",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 66, "name": "Burke-Litwin Model", "category": "Change & Organizational Management",
         "core_function": "Causal links among 12 organizational variables",
         "typical_uses": "Link change to performance and culture",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 67, "name": "Galbraith's Star Model", "category": "Change & Organizational Management",
         "core_function": "Align strategy, structure, processes, rewards, people, metrics",
         "typical_uses": "Design effective org structures",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 68, "name": "Greiner's Growth Model", "category": "Change & Organizational Management",
         "core_function": "Five phases of organizational evolution",
         "typical_uses": "Anticipate crises & plan transitions",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 69, "name": "Appreciative Inquiry", "category": "Change & Organizational Management",
         "core_function": "Strength-based change methodology",
         "typical_uses": "Engage stakeholders in positive change",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 70, "name": "Cultural Web", "category": "Change & Organizational Management",
         "core_function": "Map organizational culture elements",
         "typical_uses": "Diagnose and reshape culture",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Digital Marketing & Customer Experience
        {"id": 71, "name": "RFM Analysis", "category": "Digital Marketing & Customer Experience",
         "core_function": "Recency, Frequency, Monetary customer segmentation",
         "typical_uses": "Target high-value customer segments",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 72, "name": "CLV Calculation", "category": "Digital Marketing & Customer Experience",
         "core_function": "Customer Lifetime Value estimation",
         "typical_uses": "Inform marketing investment & loyalty strategies",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 73, "name": "NPS (Net Promoter Score)", "category": "Digital Marketing & Customer Experience",
         "core_function": "Measure customer advocacy",
         "typical_uses": "Track customer loyalty & growth potential",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 4},
        
        {"id": 74, "name": "CAC / CLTV Ratio", "category": "Digital Marketing & Customer Experience",
         "core_function": "Compare customer acquisition cost vs lifetime value",
         "typical_uses": "Evaluate acquisition efficiency",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 75, "name": "5A's Model", "category": "Digital Marketing & Customer Experience",
         "core_function": "Aware, Appeal, Ask, Act, Advocate",
         "typical_uses": "Map digital customer journey",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 76, "name": "PESO Model", "category": "Digital Marketing & Customer Experience",
         "core_function": "Paid, Earned, Shared, Owned media integration",
         "typical_uses": "Integrated communications planning",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 77, "name": "POEM Framework", "category": "Digital Marketing & Customer Experience",
         "core_function": "Paid, Owned, Earned Media classification",
         "typical_uses": "Guide content & channel mix",
         "complexity": 2, "time_to_implement": 2, "cost": 1, "effectiveness": 3},
        
        {"id": 78, "name": "Omnichannel Marketing", "category": "Digital Marketing & Customer Experience",
         "core_function": "Seamless CX across channels",
         "typical_uses": "Enhance loyalty & conversion rates",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5},
        
        {"id": 79, "name": "Hub-and-Spoke Content Model", "category": "Digital Marketing & Customer Experience",
         "core_function": "Central hub of core content with topic-specific spokes",
         "typical_uses": "SEO & content marketing strategy",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 80, "name": "Agile Marketing", "category": "Digital Marketing & Customer Experience",
         "core_function": "Apply agile principles to marketing",
         "typical_uses": "Rapidly iterate campaigns; improve ROI",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Financial & Investment Analysis
        {"id": 81, "name": "DuPont Analysis", "category": "Financial & Investment Analysis",
         "core_function": "Decompose ROE into component ratios",
         "typical_uses": "Diagnose profitability drivers",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 82, "name": "Value Chain Analysis", "category": "Financial & Investment Analysis",
         "core_function": "Map primary & support activities",
         "typical_uses": "Identify sources of margin & innovation opportunities",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 83, "name": "Altman Z-Score", "category": "Financial & Investment Analysis",
         "core_function": "Predict corporate bankruptcy risk",
         "typical_uses": "Credit risk assessment",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 84, "name": "CAPM", "category": "Financial & Investment Analysis",
         "core_function": "Model asset expected return",
         "typical_uses": "Cost of capital estimation",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 85, "name": "Black-Scholes Model", "category": "Financial & Investment Analysis",
         "core_function": "Option pricing formula",
         "typical_uses": "Derive fair price of financial derivatives",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 86, "name": "Economic Value Added (EVA)", "category": "Financial & Investment Analysis",
         "core_function": "Measure true economic profit",
         "typical_uses": "Performance measurement and valuation",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 87, "name": "Discounted Cash Flow (DCF)", "category": "Financial & Investment Analysis",
         "core_function": "Value assets based on projected cash flows",
         "typical_uses": "Investment valuation and capital budgeting",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 5},
        
        {"id": 88, "name": "Real Options Analysis", "category": "Financial & Investment Analysis",
         "core_function": "Value flexibility in investment decisions",
         "typical_uses": "Strategic investment planning under uncertainty",
         "complexity": 5, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 89, "name": "Activity-Based Costing (ABC)", "category": "Financial & Investment Analysis",
         "core_function": "Allocate costs based on activities",
         "typical_uses": "More accurate product costing and pricing",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 90, "name": "Balanced Scorecard Financial Perspective", "category": "Financial & Investment Analysis",
         "core_function": "Financial metrics within strategic framework",
         "typical_uses": "Link financial performance to strategic objectives",
         "complexity": 3, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        # Risk Management & Compliance
        {"id": 91, "name": "COSO ERM Framework", "category": "Risk Management & Compliance",
         "core_function": "Enterprise risk management components",
         "typical_uses": "Holistic risk governance",
         "complexity": 5, "time_to_implement": 5, "cost": 4, "effectiveness": 5},
        
        {"id": 92, "name": "ISO 31000", "category": "Risk Management & Compliance",
         "core_function": "Risk management principles & guidelines",
         "typical_uses": "Standardize risk processes",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 93, "name": "Risk Heat Map", "category": "Risk Management & Compliance",
         "core_function": "Visualize risk likelihood vs impact",
         "typical_uses": "Prioritize risk mitigation efforts",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        {"id": 94, "name": "Bow-Tie Analysis", "category": "Risk Management & Compliance",
         "core_function": "Link causes, controls, consequences",
         "typical_uses": "Clarify risk pathways; control effectiveness",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 95, "name": "FMEA", "category": "Risk Management & Compliance",
         "core_function": "Failure Mode & Effects Analysis",
         "typical_uses": "Preemptively address design/process failure modes",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 4},
        
        {"id": 96, "name": "Monte Carlo Simulation", "category": "Risk Management & Compliance",
         "core_function": "Model risk and uncertainty using random sampling",
         "typical_uses": "Risk assessment and scenario planning",
         "complexity": 4, "time_to_implement": 3, "cost": 3, "effectiveness": 4},
        
        {"id": 97, "name": "Value at Risk (VaR)", "category": "Risk Management & Compliance",
         "core_function": "Quantify potential losses in portfolio",
         "typical_uses": "Financial risk measurement and capital allocation",
         "complexity": 4, "time_to_implement": 3, "cost": 2, "effectiveness": 4},
        
        {"id": 98, "name": "Stress Testing", "category": "Risk Management & Compliance",
         "core_function": "Test performance under adverse conditions",
         "typical_uses": "Assess resilience and capital adequacy",
         "complexity": 3, "time_to_implement": 2, "cost": 2, "effectiveness": 4},
        
        {"id": 99, "name": "SIPOC Diagram", "category": "Risk Management & Compliance",
         "core_function": "Suppliers, Inputs, Process, Outputs, Customers",
         "typical_uses": "High-level process mapping for risk identification",
         "complexity": 2, "time_to_implement": 1, "cost": 1, "effectiveness": 3},
        
        {"id": 100, "name": "Business Continuity Planning", "category": "Risk Management & Compliance",
         "core_function": "Ensure business operations during disruptions",
         "typical_uses": "Disaster recovery and operational resilience",
         "complexity": 4, "time_to_implement": 4, "cost": 3, "effectiveness": 5}
    ]
    
    return pd.DataFrame(frameworks_data)

def get_framework_categories():
    """Return list of all framework categories"""
    return [
        "Strategic Planning Frameworks",
        "Marketing Frameworks", 
        "Quality & Operations Excellence",
        "Innovation & Design",
        "Decision-Making & Analysis",
        "Project & Portfolio Management",
        "Change & Organizational Management",
        "Digital Marketing & Customer Experience",
        "Financial & Investment Analysis",
        "Risk Management & Compliance"
    ]

def get_framework_by_name(name):
    """Get a specific framework by name"""
    df = get_all_frameworks()
    framework = df[df['name'] == name]
    return framework.iloc[0] if not framework.empty else None

def get_frameworks_by_category(category):
    """Get all frameworks in a specific category"""
    df = get_all_frameworks()
    return df[df['category'] == category]

def get_industry_framework_mapping():
    """Return mapping of industries to recommended frameworks"""
    return {
        "Technology/Software": [
            "Agile Marketing", "Scrum", "Kanban", "Design Thinking", "Lean Canvas",
            "Customer Journey Mapping", "RACE Framework", "Blue Ocean Strategy"
        ],
        "Manufacturing": [
            "Lean Management", "Six Sigma", "Lean Six Sigma", "PDCA Cycle", "5S Methodology",
            "Total Quality Management (TQM)", "DMAIC", "Value Chain Analysis"
        ],
        "Healthcare": [
            "PDCA Cycle", "Six Sigma", "FMEA", "Risk Heat Map", "Quality Function Deployment",
            "ISO 9001 Quality Management", "Business Continuity Planning", "COSO ERM Framework"
        ],
        "Financial Services": [
            "COSO ERM Framework", "Value at Risk (VaR)", "Stress Testing", "Monte Carlo Simulation",
            "CAPM", "Black-Scholes Model", "Basel III Compliance", "Risk Heat Map"
        ],
        "Retail/E-commerce": [
            "Customer Journey Mapping", "RFM Analysis", "CLV Calculation", "Omnichannel Marketing",
            "PESO Model", "NPS (Net Promoter Score)", "A/B Testing", "Conversion Funnel Analysis"
        ],
        "Consulting": [
            "SWOT Analysis", "Porter's Five Forces", "McKinsey 7S Framework", "Balanced Scorecard",
            "Business Model Canvas", "Value Chain Analysis", "Force Field Analysis", "MOST Analysis"
        ],
        "Non-Profit": [
            "Balanced Scorecard", "SWOT Analysis", "Appreciative Inquiry", "Cultural Web",
            "Force Field Analysis", "Kotter's 8-Step Model", "Customer Journey Mapping", "MOST Analysis"
        ],
        "Education": [
            "Appreciative Inquiry", "Design Thinking", "PDCA Cycle", "Customer Journey Mapping",
            "Balanced Scorecard", "Cultural Web", "Kotter's 8-Step Model", "ADKAR Model"
        ],
        "Government/Public Sector": [
            "Balanced Scorecard", "SWOT Analysis", "PESTEL Analysis", "Stakeholder Analysis",
            "Risk Heat Map", "Business Continuity Planning", "Change Management", "Performance Measurement"
        ],
        "Energy/Utilities": [
            "Risk Heat Map", "FMEA", "ISO 9001 Quality Management", "Business Continuity Planning",
            "COSO ERM Framework", "Stress Testing", "Environmental Impact Assessment", "Regulatory Compliance"
        ]
    }